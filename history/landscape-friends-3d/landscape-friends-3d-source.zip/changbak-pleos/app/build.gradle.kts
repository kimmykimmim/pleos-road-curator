import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
}

android {
    namespace = "dev.changbak.explorer"
    compileSdk = 34
    buildToolsVersion = "36.0.0"

    defaultConfig {
        applicationId = "dev.changbak.explorer"
        minSdk = 28
        targetSdk = 34
        versionCode = 4
        versionName = "0.4.0"
        testInstrumentationRunner = "dev.changbak.explorer.SceneRenderCheck"
    }

    // Compile against the SDK's car API. Runtime/device requirements live in the manifest.
    useLibrary("android.car")

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // Built-in Kotlin requires Kotlin sources to be registered with the Kotlin set.
    sourceSets.named("test") {
        kotlin.directories += rootProject.file("tests/audio").path
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}

// AGP 9 provides Kotlin support. Do not add org.jetbrains.kotlin.android.
kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    implementation("ai.pleos.playground:TextToSpeech:3.3.1")
    implementation("ai.pleos.playground:SpeechToText:3.3.1")
    testImplementation("junit:junit:4.13.2")
}
