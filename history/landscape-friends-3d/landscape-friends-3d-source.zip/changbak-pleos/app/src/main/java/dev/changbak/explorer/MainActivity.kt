package dev.changbak.explorer

import android.app.Activity
import android.app.AlertDialog
import android.car.Car
import android.car.drivingstate.CarUxRestrictions
import android.car.drivingstate.CarUxRestrictionsManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import dev.changbak.explorer.audio.VoiceGuide
import dev.changbak.explorer.domain.*

/** Pleos owns the driving view and climate bar. This Activity occupies only the app area. */
class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var store: TravelStore
    private lateinit var state: TravelState
    private lateinit var voice: VoiceGuide
    // Everyday conversation is session-only: destinations and moods never enter preferences.
    private var companion = CompanionState()
    private var sceneView: LandscapeFriend3DView? = null
    private var speechState = "idle"
    private var sceneResting = false
    private val undo = ArrayDeque<TravelState>()
    private var foreground = false
    private var armed = false
    private var voiceConsent = false
    private var carReady = false
    private var restricted = true
    private var car: Car? = null
    private var restrictions: CarUxRestrictionsManager? = null
    private var reply = ""
    private var voiceStatus = "마이크는 눌렀을 때 켜져요"
    private var statusView: TextView? = null
    private var micButton: Button? = null
    private var dialog: AlertDialog? = null
    private val blue = Color.rgb(37, 105, 235)
    private val ink = Color.rgb(33, 53, 79)
    private val muted = Color.rgb(103, 124, 150)
    private val pageColor = Color.rgb(246, 249, 254)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = TravelStore(this)
        state = store.restore()
        voice = VoiceGuide(this, onState = { label -> runOnUiThread {
            speechState = label
            voiceStatus = when (label) {
                "speaking" -> "친구의 이야기를 듣는 중"
                "listening" -> "듣고 있어요"
                "starting" -> "소리를 준비하고 있어요"
                "quiet" -> "다시 말하고 싶으면 마이크를 눌러요"
                else -> if (state.phase == CloudPhase.KEEPSAKE) "궁금한 기억을 물어봐도 좋아요" else "천천히, 창밖을 살펴봐요"
            }
            if (::voice.isInitialized && !voice.enabled) armed = false
            statusView?.text = voiceStatus
            updateMicLabel()
        } }, onCommand = {}, onError = { message -> runOnUiThread {
            voiceStatus = message
            if (::voice.isInitialized && !voice.enabled) armed = false
            statusView?.text = message
            updateMicLabel()
        } }, onUtterance = { words -> runOnUiThread {
            if (armed && voiceConsent && isConversable() && dialog == null) acceptWords(words)
        } })
        render()
        connectCar()
    }

    private fun connectCar() {
        try {
            car = Car.createCar(this, handler, Car.CAR_WAIT_TIMEOUT_DO_NOT_WAIT) { connected, ready -> runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                carReady = ready
                if (ready) try {
                    restrictions = connected.getCarManager(Car.CAR_UX_RESTRICTION_SERVICE) as CarUxRestrictionsManager
                    restrictions?.registerListener(::updateRestrictions)
                    restrictions?.currentCarUxRestrictions?.let(::updateRestrictions)
                } catch (error: Exception) {
                    carReady = false; restricted = true; backgroundPause()
                    Log.w("LandscapeFriends", "Vehicle connection unavailable", error)
                } else { restricted = true; backgroundPause() }
                render()
            } }
        } catch (error: Exception) {
            carReady = false; restricted = true
            Log.w("LandscapeFriends", "Vehicle API unavailable", error)
            render()
        }
    }

    private fun updateRestrictions(value: CarUxRestrictions) {
        carReady = true
        restricted = value.isRequiresDistractionOptimization
        if (restricted) { dialog?.dismiss(); backgroundPause() }
        else if (state.phase == CloudPhase.WELCOME) sceneResting = false
        render()
    }
    override fun onResume() { super.onResume(); foreground = true; render() }
    override fun onPause() {
        foreground = false; voiceConsent = false
        dialog?.dismiss(); backgroundPause()
        super.onPause()
    }
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        sceneView?.releaseScene(); sceneView = null
        voice.release()
        runCatching { restrictions?.unregisterListener(); car?.disconnect() }
        super.onDestroy()
    }
    private fun backgroundPause() {
        sceneResting = true
        sceneView?.pauseScene()
        quiet()
        companion = companion.copy(pending = TalkTopic.NONE)
        if (::state.isInitialized) {
            state = state.copy(
                phase = if (state.phase == CloudPhase.WATCHING) CloudPhase.RESTING else state.phase,
                pending = FriendChoice.NONE,
            )
            if (::store.isInitialized) store.save(state)
        }
    }
    private fun isConversable() = foreground && carReady && !restricted &&
        (state.phase == CloudPhase.WATCHING || state.phase == CloudPhase.KEEPSAKE)
    private fun quiet() { armed = false; if (::voice.isInitialized) voice.suspend() }
    private fun updateMicLabel() {
        micButton?.text = if (armed) "마이크 끄기" else "이야기하기"
        updateSceneExpression()
    }
    private fun updateSceneExpression() {
        sceneView?.setSpeaking(speechState == "speaking")
        sceneView?.setListening(speechState == "listening" && armed)
        sceneView?.setMood(if (sceneResting) "sleepy" else companion.mood.name.lowercase())
    }
    private fun syncSceneLifecycle() {
        if (foreground && carReady && !restricted && dialog == null) sceneView?.resumeScene()
        else sceneView?.pauseScene()
    }
    private fun addScene(parent: LinearLayout, height: Int) {
        val scene = LandscapeFriend3DView(this, state).apply {
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        sceneView = scene
        parent.addView(scene, LinearLayout.LayoutParams(-1, dp(height)))
        updateSceneExpression()
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int = 24) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun column() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun label(value: String, size: Float, color: Int = ink, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); includeFontPadding = false
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setLineSpacing(dp(5).toFloat(), 1f)
    }
    private fun gap(parent: LinearLayout, amount: Int) = parent.addView(View(this), LinearLayout.LayoutParams(1, dp(amount)))
    private fun button(value: String, primary: Boolean = false, action: () -> Unit) = Button(this).apply {
        text = value; textSize = 25f; isAllCaps = false
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(if (primary) Color.WHITE else ink)
        background = rounded(if (primary) blue else Color.rgb(235, 242, 252), 22)
        minimumHeight = dp(76); minHeight = dp(76)
        setPadding(dp(22), dp(12), dp(22), dp(12))
        setOnClickListener { action() }
    }
    private fun fullButton(parent: LinearLayout, value: String, primary: Boolean = false, action: () -> Unit): Button {
        return button(value, primary, action).also { parent.addView(it, LinearLayout.LayoutParams(-1, dp(86))) }
    }
    private fun pair(parent: LinearLayout, first: Button, second: Button) {
        val actions = row()
        actions.addView(first, LinearLayout.LayoutParams(0, dp(80), 1f).apply { marginEnd = dp(12) })
        actions.addView(second, LinearLayout.LayoutParams(0, dp(80), 1f))
        parent.addView(actions)
    }

    private fun render() {
        if (isDestroyed || !::state.isInitialized) return
        sceneView?.releaseScene(); sceneView = null
        micButton = null; statusView = null
        val wide = resources.configuration.screenWidthDp >= 900
        val root = column().apply {
            setBackgroundColor(pageColor)
            setPadding(dp(if (wide) 40 else 24), dp(24), dp(if (wide) 40 else 24), dp(24))
        }
        val header = row()
        val brand = column()
        brand.addView(label("창밖 탐험", 17f, muted)); gap(brand, 7)
        brand.addView(label("풍경 친구", 29f, ink, true))
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        if (state.phase == CloudPhase.WATCHING || state.phase == CloudPhase.RESTING) {
            header.addView(button("여행 마치기") { if (foreground && !restricted) applyTurn(TravelEngine.finish(state)) },
                LinearLayout.LayoutParams(-2, dp(70)).apply { marginEnd = dp(12) })
        }
        header.addView(button("보호자") { if (!restricted && carReady) parentMenu() }, LinearLayout.LayoutParams(-2, dp(70)))
        root.addView(header); gap(root, 28)
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val body = LinearLayout(this).apply { orientation = if (wide) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL }
        scroll.addView(body, FrameLayout.LayoutParams(-1, -1))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        if (wide) {
            val sky = column().apply {
                gravity = Gravity.CENTER_HORIZONTAL
                background = rounded(Color.rgb(232, 243, 255), 34)
                setPadding(dp(24), dp(36), dp(24), dp(26))
            }
            sky.addView(label("같이 가는 여행 친구", 23f, muted))
            addScene(sky, 500)
            gap(sky, 16)
            sky.addView(label(friendTitle(state), 29f, ink, true).apply { gravity = Gravity.CENTER })
            gap(sky, 14)
            sky.addView(label("네 이야기에 귀 기울이고 있어", 21f, muted).apply { gravity = Gravity.CENTER })
            body.addView(sky, LinearLayout.LayoutParams(0, -1, 0.54f).apply { marginEnd = dp(28) })
        }
        val card = column().apply {
            background = rounded(Color.WHITE, 34)
            setPadding(dp(if (wide) 42 else 26), dp(40), dp(if (wide) 42 else 26), dp(32))
        }
        body.addView(card, if (wide) LinearLayout.LayoutParams(0, -1, 0.46f) else LinearLayout.LayoutParams(-1, -1))
        if (!wide && carReady && !restricted) { addScene(card, 280); gap(card, 20) }
        when {
            !carReady -> { card.addView(label("차량과 연결하고 있어요", 39f, ink, true)); gap(card, 24); card.addView(label("잠시만 기다려 주세요.", 28f, muted)) }
            restricted -> { card.addView(label("지금은 쉬어가요", 43f, ink, true)); gap(card, 24); card.addView(label("차가 멈추면 이어서 만나요.", 29f, muted)) }
            state.phase == CloudPhase.WELCOME -> welcome(card)
            state.phase == CloudPhase.WATCHING -> watching(card)
            state.phase == CloudPhase.RESTING -> resting(card)
            else -> keepsake(card)
        }
        setContentView(root)
        syncSceneLifecycle()
    }

    private fun welcome(card: LinearLayout) {
        card.addView(label("안녕,\n나랑 같이 갈래?", 44f, ink, true)); gap(card, 28)
        card.addView(label("네 이야기와 풍경을\n함께 기억할게.", 29f, muted)); gap(card, 36)
        fullButton(card, "같이 놀자", true) { beginConversation() }
        gap(card, 20); card.addView(label("한마디만 해도 좋아요", 22f, muted))
    }
    private fun watching(card: LinearLayout) {
        card.addView(label("친구의 한마디", 22f, blue, true)); gap(card, 24)
        card.addView(label(reply.ifBlank { "오늘 어디 가?" }, 35f, ink, true)); gap(card, 38)
        pendingChoiceButtons(card)
        micButton = fullButton(card, if (armed) "마이크 끄기" else "이야기하기", true) { toggleMicrophone() }
        gap(card, 14)
        fullButton(card, "잠깐 쉴래") { applyTurn(TravelEngine.rest(state)) }
        gap(card, 22)
        statusView = label(voiceStatus, 21f, muted).also { card.addView(it) }
    }
    private fun resting(card: LinearLayout) {
        card.addView(label("잠깐 쉬어도 좋아", 43f, ink, true)); gap(card, 24)
        card.addView(label("이야기하고 싶어지면\n그때 다시 만나.", 29f, muted)); gap(card, 40)
        fullButton(card, "다시 만날래", true) { beginConversation() }
        gap(card, 22); card.addView(label("지금은 마이크가 꺼져 있어요", 21f, muted))
    }
    private fun hasFriend(saved: TravelState) = saved.body != null || saved.memories.isNotEmpty()
    private fun friendTitle(saved: TravelState) = saved.body?.nickname?.takeIf(String::isNotBlank)
        ?: saved.body?.label?.takeIf { it.isNotBlank() && it != "구름 친구" } ?: "우리의 풍경 친구"
    private fun currentMemories(saved: TravelState): List<TravelMemory> =
        saved.memories.asReversed().distinctBy { it.trait.part }.asReversed()
    private fun memoryLine(saved: TravelState): String {
        val memories = currentMemories(saved).takeLast(3)
        if (memories.isEmpty()) return if (hasFriend(saved)) "네가 들려준 모습을 기억하고 있어." else "오늘은 풍경과 함께 쉬었어요."
        return memories.joinToString(", ") { "${it.source.label}에서 ${it.trait.part.label}" } + "."
    }
    private fun keepsake(card: LinearLayout) {
        card.addView(label("도착해서도 함께", 22f, blue, true)); gap(card, 24)
        card.addView(label(reply.ifBlank { "오늘 같이 와서 좋았어. 너는 어땠어?" }, 34f, ink, true)); gap(card, 30)
        pendingChoiceButtons(card)
        micButton = fullButton(card, if (armed) "마이크 끄기" else "이야기하기", true) { toggleMicrophone() }
        gap(card, 14)
        pair(card, button("잠깐 쉴래") { applyTurn(TravelEngine.rest(state)) }, button("새 여행") { newTrip() })
        gap(card, 20)
        statusView = label(voiceStatus, 21f, muted).also { card.addView(it) }
    }

    private fun pendingChoiceButtons(card: LinearLayout) {
        if (state.pending == FriendChoice.ADD_WINGS) {
            pair(card, button("날개 달아줘") { acceptWords("응") }, button("지금 모습이 좋아") { acceptWords("아니") })
            gap(card, 18)
        }
    }

    private fun beginConversation() {
        if (!foreground || restricted || !carReady) return
        quiet()
        sceneResting = false
        val start = TravelEngine.start(state)
        val greeting = CompanionEngine.open(companion, start.state)
        companion = greeting.state
        applyTurn(start.copy(reply = greeting.reply), false)
    }

    private fun applyConversation(turn: CompanionTurn, continueListening: Boolean = armed) {
        if (!isConversable()) return
        sceneResting = false
        companion = turn.state
        reply = turn.reply
        // This conversation state intentionally stays in memory, outside TravelStore.
        render()
        say(turn.reply, continueListening)
    }

    private fun say(words: String?, listenAfter: Boolean) {
        if (words.isNullOrBlank() || !foreground || restricted || !carReady) return
        syncSceneLifecycle()
        val shouldListen = listenAfter && voiceConsent && isConversable()
        // A completed trip is conversational, but completion itself must not reopen the mic.
        if (!shouldListen && voice.enabled) quiet()
        voice.speak(words)
        if (shouldListen) { armed = voice.enableCommands(); updateMicLabel() }
    }
    private fun rememberUndo() { undo.addLast(state); while (undo.size > 10) undo.removeFirst() }
    private fun applyTurn(turn: TravelTurn, continueListening: Boolean = armed) {
        if (!foreground || restricted || !carReady) return
        sceneResting = turn.outcome == TravelOutcome.REST
        if (turn.outcome == TravelOutcome.UNDO) { undoLast(continueListening); return }
        if (turn.outcome == TravelOutcome.REPEAT) { say(reply.ifBlank { "눈에 들어온 모습을 네 말로 들려줘." }, continueListening); return }
        if (turn.outcome in setOf(TravelOutcome.OBSERVED, TravelOutcome.CORRECTED) &&
            (turn.state.body != state.body || turn.state.memories != state.memories)) rememberUndo()
        if (turn.outcome in setOf(TravelOutcome.OBSERVED, TravelOutcome.CORRECTED, TravelOutcome.UNCHANGED, TravelOutcome.REST, TravelOutcome.FINISH)) {
            companion = companion.copy(pending = TalkTopic.NONE)
        }
        state = turn.state
        if (!turn.reply.isNullOrBlank()) reply = turn.reply!!
        val endListening = turn.outcome == TravelOutcome.FINISH || turn.outcome == TravelOutcome.REST || !isConversable()
        if (endListening) quiet()
        store.save(state)
        Log.i("LandscapeFriends", "Travel turn: ${turn.outcome}; phase=${state.phase}; memories=${state.memories.size}")
        render()
        say(turn.reply, continueListening && !endListening)
    }
    private fun acceptWords(words: String) {
        if (!isConversable()) return
        val compact = words.replace(Regex("[\\s\\p{Z}\\p{P}]"), "")
        if (compact in setOf("쉬고싶어", "쉬고싶어요", "쉬고싶다", "쉬자", "잠깐쉬자", "좀쉴래", "쉴래", "잠깐쉴래", "조용히있고싶어", "조용히있자", "조용히", "그만이야기할래", "그만말할래", "말하기싫어", "말하기싫어요", "이야기하기싫어")) {
            applyTurn(TravelEngine.rest(state))
            return
        }
        if (companion.pending == TalkTopic.PLAN && compact in setOf("모르겠어", "아직모르겠어", "생각안나", "그냥갈래")) {
            CompanionEngine.respond(companion, words, state)?.let { applyConversation(it); return }
        }
        val travel = TravelEngine.observe(state, words)
        // Observation, corrections, source questions and explicit choices belong to the trip.
        // Everyday answers never become evidence that a landscape was seen.
        val sourceQuestion = Regex("꼬리|날개|빛깔|걸음|어떻게움직|어떻게생겼|귀(?:가|는|를|에|모습)|몸(?:이|은|을|에|모습)").containsMatchIn(compact) ||
            (compact.contains("기억") && Regex("풍경|창밖|봤|보았|내가본|우리가본").containsMatchIn(compact)) ||
            ((compact.contains("이름") || compact.contains("별명")) && Regex("뭐|무엇|알려|어떤").containsMatchIn(compact))
        val hasTripPriority = travel.outcome !in setOf(TravelOutcome.CHAT, TravelOutcome.IGNORED) ||
            state.pending != FriendChoice.NONE || travel.state.pending != FriendChoice.NONE || sourceQuestion
        if (!hasTripPriority) {
            CompanionEngine.respond(companion, words, state)?.let { applyConversation(it); return }
        }
        if (sourceQuestion) companion = companion.copy(pending = TalkTopic.NONE)
        applyTurn(travel)
    }
    private fun undoLast(continueListening: Boolean = armed) {
        if (!isConversable()) return
        sceneResting = false
        if (undo.isEmpty()) { say("아직 되돌릴 말이 없어.", continueListening); return }
        val phase = state.phase
        state = undo.removeLast().copy(phase = phase, pending = FriendChoice.NONE)
        companion = companion.copy(pending = TalkTopic.NONE)
        reply = "괜찮아. 방금 전 모습으로 돌아왔어."
        store.save(state); render(); say(reply, continueListening)
    }
    private fun askAbout(part: FriendPart) {
        if (isConversable()) acceptWords("왜 ${part.label} 모습이 이렇게 됐어?")
    }
    private fun memoryQuestions() {
        if (!isConversable()) return
        quiet()
        val remembered = currentMemories(state).takeLast(3)
        if (remembered.isEmpty()) {
            acceptWords("어떤 풍경을 기억해?")
            return
        }
        showDialog(AlertDialog.Builder(this).setTitle("어떤 기억이 궁금해?")
            .setItems(remembered.map { "${it.source.label} → ${it.trait.part.label}" }.toTypedArray()) { _, index ->
                handler.post { askAbout(remembered[index].trait.part) }
            }.setNegativeButton("닫기", null).create())
    }
    private fun toggleMicrophone() {
        if (!isConversable()) return
        if (armed) { quiet(); voiceStatus = "마이크가 꺼져 있어요"; render(); return }
        sceneResting = false
        syncSceneLifecycle()
        if (voiceConsent) { armed = voice.enableCommands(); render(); return }
        quiet()
        showDialog(AlertDialog.Builder(this).setTitle("친구와 이야기할까요?")
            .setMessage("오늘 기분이나 보이는 풍경을 들려줘요.\n\n음성은 차량 안에서 처리해요. 풍경의 종류와 특징, 친구의 모습과 별명만 기기에 남겨요. 행선지와 기분은 이번 실행에서만 기억하며 녹음과 문장 전체는 저장하지 않아요. 쉬거나 앱을 벗어나면 마이크가 꺼져요.")
            .setNegativeButton("나중에", null)
            .setPositiveButton("마이크 켜기") { _, _ -> if (isConversable()) { voiceConsent = true; armed = voice.enableCommands(); render() } }.create())
    }
    private fun showDialog(next: AlertDialog) {
        if (!foreground || restricted || !carReady || isFinishing || isDestroyed) return
        dialog?.dismiss(); dialog = next
        sceneView?.pauseScene()
        next.setOnDismissListener { if (dialog === next) { dialog = null; syncSceneLifecycle() } }
        next.show()
    }
    private fun parentMenu() {
        quiet()
        val items = arrayOf("말 대신 입력해 보기", "친구의 기억 물어보기", "방금 말 되돌리기", "지난 풍경 친구 보기", "음성과 저장 안내", "처음부터 새 여행")
        showDialog(AlertDialog.Builder(this).setTitle("보호자 메뉴").setItems(items) { _, index ->
            when (index) {
                0 -> handler.post { tryWords() }
                1 -> handler.post { memoryQuestions() }
                2 -> handler.post { undoLast(false) }
                3 -> handler.post { previousKeepsake() }
                4 -> handler.post { information() }
                5 -> handler.post { newTrip() }
            }
        }.setNegativeButton("닫기", null).create())
    }
    /** Text and example inputs use exactly the same reducer as the microphone. */
    private fun tryWords() {
        if (!foreground || restricted || !carReady) return
        quiet()
        val panel = column().apply { setPadding(dp(24), dp(16), dp(24), dp(12)) }
        val field = EditText(this).apply {
            hint = "아이가 한 말을 입력해 주세요"; textSize = 23f; maxLines = 3
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            filters = arrayOf(android.text.InputFilter.LengthFilter(160))
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
        }
        panel.addView(field, LinearLayout.LayoutParams(-1, dp(100))); gap(panel, 12)
        panel.addView(label("예시를 누르거나 자유롭게 입력해 보세요.", 19f, muted)); gap(panel, 12)
        var entryDialog: AlertDialog? = null
        fun submit(words: String) {
            if (words.isBlank()) return
            entryDialog?.dismiss()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(field.windowToken, 0)
            if (!foreground || restricted || !carReady) return
            // Post-arrival input talks to the same friend instead of silently starting over.
            if (state.phase == CloudPhase.WELCOME || state.phase == CloudPhase.RESTING) {
                state = TravelEngine.start(state).state
                companion = CompanionEngine.open(companion, state).state
            }
            acceptWords(words)
        }
        listOf("할머니 집에 가", "오늘 신나", "너는 어때?", "구름이 동글동글해", "나뭇잎이 살랑살랑 움직여", "강물이 반짝여").forEach { example ->
            panel.addView(button(example) { submit(example) }, LinearLayout.LayoutParams(-1, dp(64)).apply { bottomMargin = dp(8) })
        }
        val inputScroll = ScrollView(this).apply { addView(panel); isFillViewport = true }
        entryDialog = AlertDialog.Builder(this).setTitle("말 대신 입력해 보기").setView(inputScroll)
            .setNegativeButton("닫기", null).setPositiveButton("말 전하기", null).create()
        showDialog(entryDialog!!)
        entryDialog!!.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { submit(field.text.toString()) }
    }
    private fun information() {
        val message = "입체 친구가 목소리에 맞춰 반응해요. 지금은 정해진 규칙으로 행선지와 기분에 대해 짧게 대화하는 시연이며, 생성형 AI 대화는 아직 연결하지 않았어요.\n\n풍경의 종류와 특징, 친구의 모습과 별명만 기기에 남아요. 행선지와 기분은 이번 실행에서만 기억하고 녹음과 전체 발화는 저장하지 않아요. 실제 풍경을 촬영하거나 판별하지 않아요.\n\n말이 없으면 듣기를 마쳐요. 다시 이야기할 때 버튼을 눌러 주세요.\n\n${voice.engineLabel}\n현재 버전은 정차 상태에서 시연할 수 있어요."
        showDialog(AlertDialog.Builder(this).setTitle("음성과 저장 안내").setMessage(message).setPositiveButton("확인", null).create())
    }
    private fun previousKeepsake() {
        val saved = store.lastKeepsake()
        if (saved == null || !hasFriend(saved)) {
            showDialog(AlertDialog.Builder(this).setTitle("아직 여행 그림이 없어요").setMessage("여행을 마치면 풍경 친구 한 장이 남아요.").setPositiveButton("확인", null).create()); return
        }
        val panel = column().apply { setPadding(dp(28), dp(12), dp(28), dp(24)) }
        panel.addView(LandscapeFriendView(this, saved, true), LinearLayout.LayoutParams(-1, dp(280)))
        panel.addView(label(memoryLine(saved), 23f))
        showDialog(AlertDialog.Builder(this).setTitle(friendTitle(saved)).setView(panel).setPositiveButton("닫기", null).create())
    }
    private fun newTrip() {
        if (!foreground || restricted || !carReady) return
        quiet()
        showDialog(AlertDialog.Builder(this).setTitle("새 여행을 시작할까요?")
            .setMessage("마지막 여행 그림은 보호자 메뉴에서 다시 볼 수 있어요.")
            .setNegativeButton("취소", null).setPositiveButton("새 여행") { _, _ ->
                if (foreground && !restricted && carReady) {
                    state = TravelEngine.create(); companion = CompanionState(); sceneResting = false; undo.clear(); reply = ""; voiceConsent = false; store.save(state); render()
                }
            }.create())
    }
}
