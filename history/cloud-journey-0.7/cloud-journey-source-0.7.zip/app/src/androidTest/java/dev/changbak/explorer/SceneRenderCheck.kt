package dev.changbak.explorer

import android.app.Activity
import android.app.Instrumentation
import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.opengl.EGL14
import android.opengl.GLES20
import android.os.Bundle
import dev.changbak.explorer.domain.TravelEngine
import dev.changbak.explorer.domain.TravelState
import dev.changbak.explorer.domain.*
import java.io.File
import java.nio.ByteBuffer

/** Renders synthetic art to an offscreen buffer. Does not capture or operate the user's screen. */
class SceneRenderCheck : Instrumentation() {
    private var requestedCheck: String? = null
    override fun onCreate(arguments: Bundle?) {
        super.onCreate(arguments)
        requestedCheck = arguments?.getString("check")
        start()
    }

    override fun onStart() {
        val report = Bundle()
        try {
            if (requestedCheck == "chat") {
                report.putString("result", FriendChatTransportCheck.run(targetContext))
                finish(Activity.RESULT_OK, report)
                return
            }
            if (requestedCheck == "world") {
                checkCloudWorld(report)
                finish(Activity.RESULT_OK, report)
                return
            }
            if (requestedCheck == "motion") {
                checkMotion(report)
                finish(Activity.RESULT_OK, report)
                return
            }
            val output = File(targetContext.filesDir, "scene-render-check").apply { mkdirs() }
            var sample = TravelEngine.start(TravelEngine.create()).state
            sample = TravelEngine.observe(sample, "구름이 동글동글해").state
            val cloudPixels = render(sample, File(output, "friend-cloud.png"))
            sample = TravelEngine.observe(sample, "나뭇잎이 살랑살랑 움직여").state
            sample = TravelEngine.observe(sample, "강물이 반짝여").state
            val landscapePixels = render(sample, File(output, "friend-landscape.png"))
            sample = TravelEngine.observe(sample, "그거 강이 아니라 바다였어").state
            render(sample, File(output, "friend-sea.png"))
            sample = TravelEngine.observe(sample, "날개 달아줘").state
            render(sample, File(output, "friend-wings.png"))
            val changed = cloudPixels.indices.count { cloudPixels[it] != landscapePixels[it] }
            check(changed > 2500) { "Accumulated scenery did not visibly change the character" }
            val green = landscapePixels.count { c ->
                val r = c shr 16 and 255; val g = c shr 8 and 255; val b = c and 255
                g > r + 12 && g > b + 3
            }
            check(green > 300) { "Leaf ears are missing from the rendered sample" }
            report.putString("result", "PASS: four offscreen 3D renders, scenery changes, and leaf ears")
            report.putString("artifacts", output.absolutePath)
            report.putInt("changed_pixels", changed)
            report.putInt("leaf_pixels", green)
            finish(Activity.RESULT_OK, report)
        } catch (error: Throwable) {
            report.putString("result", "FAIL: ${error.javaClass.simpleName}: ${error.message}")
            finish(Activity.RESULT_CANCELED, report)
        }
    }

    private fun checkCloudWorld(report: Bundle) {
        val output = File(targetContext.filesDir, "cloud-world-render-check").apply { mkdirs() }
        val empty = CloudPlayEngine.start(CloudPlayEngine.create()).state
        val emptyPixels = render(empty, File(output, "01-empty-sky.png"), expectEmpty = true)
        val rabbit = CloudPlayEngine.observe(empty, "저 구름 토끼 같아").state
        val rabbitPixels = render(rabbit, File(output, "02-rabbit-friend.png"))
        val preview = CloudPlayEngine.observe(rabbit, "저쪽 구름은 고래 같아").state
        val background = CloudPlayEngine.observe(preview, "하늘에 띄우자").state
        render(background, File(output, "03-rabbit-and-whale-cloud.png"))
        val more = CloudPlayEngine.observe(background, "공룡 구름을 친구로 만들어줘").state
        render(more, File(output, "04-two-friends-and-cloud.png"))
        val selected = CloudPlayEngine.select(more, rabbit.cloudWorld!!.activeId!!).state
        render(selected, File(output, "05-rabbit-speaking.png"))
        val backgroundOnly = CloudPlayEngine.observe(empty, "토끼 같은 구름을 하늘에 띄워줘").state
        val backgroundPixels = render(backgroundOnly, File(output, "06-background-without-face.png"))
        fun inkPixels(pixels: IntArray) = pixels.count { c -> (c shr 16 and 255) < 90 && (c shr 8 and 255) < 110 && (c and 255) < 145 }
        check(inkPixels(rabbitPixels) > 50) { "Friend face is missing" }
        check(inkPixels(backgroundPixels) == 0) { "A background cloud was given a face" }
        check(emptyPixels.distinct().size == 1) { "Empty sky contains pre-created geometry" }

        // Isolated test preferences: never reads or resets the user's current sky.
        val testContext = object : ContextWrapper(targetContext) {
            override fun getSharedPreferences(name: String, mode: Int): SharedPreferences =
                baseContext.getSharedPreferences("cloud_world_validation_only", Context.MODE_PRIVATE)
        }
        val preferences = testContext.getSharedPreferences("unused", Context.MODE_PRIVATE)
        preferences.edit().clear().commit()
        try {
            val store = CloudWorldStore(testContext)
            check(store.restore().cloudWorld!!.clouds.isEmpty()) { "Fresh store is not empty" }
            val remembered = CloudPlayEngine.remember(more).state.let {
                it.copy(cloudWorld = it.cloudWorld!!.copy(expectation = JourneyExpectation.FAMILY))
            }
            store.save(remembered.copy(cloudWorld = remembered.cloudWorld!!.copy(draft = CloudFriend(CloudForm.HEART, "하트"))))
            val restored = store.restore()
            check(restored.phase == CloudPhase.RESTING && restored.cloudWorld!!.draft == null) { "Listening or pending choice survived restore" }
            check(restored.cloudWorld!!.clouds == more.cloudWorld!!.clouds && restored.body == more.body) { "Restored sky lost roles or selected friend" }
            check(restored.cloudWorld!!.expectation == JourneyExpectation.FAMILY &&
                restored.cloudWorld!!.favoriteId == remembered.cloudWorld!!.favoriteId) { "Journey expectation or chosen memory was lost" }
            store.save(CloudPlayEngine.finish(more).state)
            store.save(CloudPlayEngine.create())
            check(store.restore().cloudWorld!!.clouds.isEmpty()) { "New trip did not reset sky" }
            check(store.lastKeepsake()!!.cloudWorld!!.clouds == more.cloudWorld!!.clouds) { "New trip erased previous keepsake" }
        } finally { preferences.edit().clear().commit() }
        report.putString("result", "PASS: empty sky, friend birth, faceless background, multiple friends, selected friend, isolated save/restore and keepsake")
        report.putString("artifacts", output.absolutePath)
        report.putInt("friend_face_pixels", inkPixels(rabbitPixels))
        report.putInt("background_face_pixels", inkPixels(backgroundPixels))
    }

    private fun checkMotion(report: Bundle) {
        val output = File(targetContext.filesDir, "cloud-motion-check").apply { mkdirs() }
        val empty = CloudPlayEngine.start(CloudPlayEngine.create()).state
        val rabbit = CloudPlayEngine.observe(empty, "저 구름 토끼 같아").state
        val preview = CloudPlayEngine.observe(rabbit, "고래 같아").state
        val friends = CloudPlayEngine.observe(preview, "친구로 만들자").state
        val selected = CloudPlayEngine.select(friends, rabbit.cloudWorld!!.activeId!!).state
        val stages = listOf(empty to rabbit, rabbit to preview, preview to friends, friends to selected)
        var frameIndex = 0
        val contrasts = mutableListOf<Long>()
        fun nextFile() = File(output, "frame-${(frameIndex++).toString().padStart(3, '0')}.png")
        stages.forEachIndexed { stage, (from, to) ->
            var last: File? = null
            for (i in 0..20) {
                val file = nextFile()
                val pixels = render(to, file, stage == 0 && i == 0) { error ->
                    createCloudTransitionRendererForCheck(from, to, i / 20f, error)
                }
                if (stage == 0 && i in listOf(0, 5, 10, 15, 20)) {
                    val bg = pixels[0]
                    contrasts.add(pixels.sumOf { c ->
                        kotlin.math.abs((c shr 16 and 255) - (bg shr 16 and 255)).toLong() +
                            kotlin.math.abs((c shr 8 and 255) - (bg shr 8 and 255)) + kotlin.math.abs((c and 255) - (bg and 255))
                    })
                }
                if (stage == 0 && i == 0) repeat(10) { file.copyTo(nextFile(), overwrite = true) }
                last = file
            }
            repeat(10) { last!!.copyTo(nextFile(), overwrite = true) }
        }
        check(contrasts.first() == 0L) { "Birth starts with a visible avatar" }
        check(contrasts.zipWithNext().all { (before, after) -> after > before }) { "Birth opacity did not progress through intermediate frames" }
        report.putString("result", "PASS: actual GLES intermediate frames for birth fade, preview fade, preview-to-friend face and movement, and speaker exchange")
        report.putString("artifacts", output.absolutePath)
        report.putString("birth_contrast_steps", contrasts.joinToString())
        report.putInt("frames", frameIndex)
    }

    private fun render(state: TravelState, output: File, expectEmpty: Boolean = false,
        factory: (((String) -> Unit) -> android.opengl.GLSurfaceView.Renderer)? = null): IntArray {
        val width = 720
        val height = 600
        val display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        check(display != EGL14.EGL_NO_DISPLAY) { "No EGL display" }
        val version = IntArray(2)
        check(EGL14.eglInitialize(display, version, 0, version, 1)) { "EGL initialization failed" }
        val configs = arrayOfNulls<android.opengl.EGLConfig>(1)
        val count = IntArray(1)
        val attributes = intArrayOf(
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8, EGL14.EGL_DEPTH_SIZE, 16, EGL14.EGL_NONE,
        )
        check(EGL14.eglChooseConfig(display, attributes, 0, configs, 0, 1, count, 0) && count[0] > 0) { "No GLES2 pbuffer config" }
        val context = EGL14.eglCreateContext(display, configs[0], EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        check(context != EGL14.EGL_NO_CONTEXT) { "No GLES2 context" }
        val surface = EGL14.eglCreatePbufferSurface(display, configs[0],
            intArrayOf(EGL14.EGL_WIDTH, width, EGL14.EGL_HEIGHT, height, EGL14.EGL_NONE), 0)
        check(surface != EGL14.EGL_NO_SURFACE) { "No pbuffer surface" }
        try {
            check(EGL14.eglMakeCurrent(display, surface, surface, context)) { "Cannot make render context current" }
            var renderError: String? = null
            val renderer = factory?.invoke { renderError = it } ?: createLandscapeRendererForCheck(state) { renderError = it }
            renderer.onSurfaceCreated(null, null)
            renderer.onSurfaceChanged(null, width, height)
            renderer.onDrawFrame(null)
            GLES20.glFinish()
            check(renderError == null) { renderError.orEmpty() }
            check(GLES20.glGetError() == GLES20.GL_NO_ERROR) { "OpenGL draw failed" }
            val rgba = ByteBuffer.allocateDirect(width * height * 4)
            GLES20.glReadPixels(0, 0, width, height, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, rgba)
            check(GLES20.glGetError() == GLES20.GL_NO_ERROR) { "OpenGL readback failed" }
            val pixels = IntArray(width * height)
            for (y in 0 until height) for (x in 0 until width) {
                val i = (y * width + x) * 4
                val r = rgba.get(i).toInt() and 255
                val g = rgba.get(i + 1).toInt() and 255
                val b = rgba.get(i + 2).toInt() and 255
                pixels[(height - 1 - y) * width + x] = (255 shl 24) or (r shl 16) or (g shl 8) or b
            }
            val background = pixels[0]
            if (!expectEmpty) check(pixels.count { it != background } > if (factory == null) 1500 else 50) { "Rendered image is blank" }
            val bitmap = Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888)
            try { output.outputStream().use { check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)) } }
            finally { bitmap.recycle() }
            return pixels
        } finally {
            EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(display, surface)
            EGL14.eglDestroyContext(display, context)
            EGL14.eglTerminate(display)
        }
    }
}
