package dev.changbak.explorer

import android.content.Context
import android.os.Handler
import android.os.Looper
import ai.pleos.playground.navi.helper.NaviHelper
import ai.pleos.playground.navi.helper.listener.NaviHelperEventListener
import ai.pleos.playground.navi.data.*
import ai.pleos.playground.navi.constants.NaviErrorCode

/** Read-only SDK connection. Destination ETA is deliberately not reused as a landmark ETA. */
class CuratorNaviSource(context: Context, private val status: (String) -> Unit) {
    private val app = context.applicationContext
    private val handler = Handler(Looper.getMainLooper())
    private var sdk: NaviHelper? = null
    private var active = false
    private val listener = object : NaviHelperEventListener {
        override fun onDestinationInfo(info: DestinationInfo) {
            handler.post { if (active) status("목적지 연결: ${info.name}\n명소별 경로와 통과 시점 연결은 준비 중이에요.") }
        }
        override fun onRouteCancelled() { handler.post { if (active) status("경로 안내가 취소됐어요. 새 경로를 기다려요.") } }
        override fun onReRouteEnded() { handler.post { if (active) { status("경로가 바뀌었어요. 새 경로를 확인해 주세요."); runCatching { sdk?.getDestinationInfo() } } } }
        override fun onError(errorCode: NaviErrorCode) { handler.post { if (active) status("내비게이션 정보를 받지 못했어요. 시연 경로로 체험할 수 있어요.") } }
    }
    fun connect() {
        close(); active = true
        try {
            sdk = NaviHelper(app).also { helper ->
                helper.initialize(onConnected = {
                    handler.post {
                        if (!active || sdk !== helper) return@post
                        runCatching { helper.addListener(listener); helper.getDestinationInfo() }
                            .onFailure { status("내비게이션 조회 권한을 확인해 주세요.") }
                    }
                }, onFailed = { handler.post { if (active) status("내비게이션에 연결하지 못했어요. 시연 경로를 이용해 주세요.") } })
            }
        } catch (_: Exception) { status("이 환경에서는 내비게이션 연결을 사용할 수 없어요.") }
    }
    fun close() {
        active = false; handler.removeCallbacksAndMessages(null)
        runCatching { sdk?.removeListener(listener); sdk?.release() }; sdk = null
    }
}
