package dev.changbak.explorer

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import dev.changbak.explorer.domain.*

/** Code-drawn landmark sketch, not a photograph or a claim about the current camera view. */
class CuratorSceneView(context: Context): View(context) {
    private var state = CuratorState()
    private var prior = state
    private var progress = 1f
    private var animator: ValueAnimator? = null
    fun present(next: CuratorState, animate: Boolean) {
        val visualChange=state.phase!=next.phase || state.currentId!=next.currentId
        if(!visualChange) { state=next; return }
        prior=state; state=next; animator?.cancel()
        if(!animate || !ValueAnimator.areAnimatorsEnabled()) { progress=1f; invalidate(); return }
        animator=ValueAnimator.ofFloat(0f,1f).apply {
            duration=700L
            addUpdateListener { progress=it.animatedValue as Float; invalidate() }; start()
        }
    }
    override fun onDetachedFromWindow() { animator?.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(canvas: Canvas) {
        if(progress<1f) { canvas.saveLayerAlpha(0f,0f,width.toFloat(),height.toFloat(),((1f-progress)*255).toInt()); drawScene(canvas,width.toFloat(),height.toFloat(),prior); canvas.restore() }
        canvas.saveLayerAlpha(0f,0f,width.toFloat(),height.toFloat(),(progress*255).toInt())
        drawScene(canvas,width.toFloat(),height.toFloat(),state); canvas.restore()
    }
    companion object {
        fun drawScene(c: Canvas,w: Float,h: Float,state: CuratorState) {
            val p=Paint(Paint.ANTI_ALIAS_FLAG)
            fun line(x1:Float,y1:Float,x2:Float,y2:Float,color:Int,width:Float) {
                p.color=color;p.strokeWidth=width;p.strokeCap=Paint.Cap.ROUND;c.drawLine(x1,y1,x2,y2,p)
            }
            val teal=Color.rgb(46,113,115);val dark=Color.rgb(55,74,81);val pale=Color.rgb(180,204,194)
            p.color=Color.rgb(208,224,214);c.drawOval(w*.06f,h*.22f,w*.94f,h*.82f,p)
            val mystery=state.phase in setOf(CuratorPhase.READY,CuratorPhase.WAITING)
            if(mystery) {
                p.color=Color.rgb(246,244,229);c.drawCircle(w*.5f,h*.46f,w*.21f,p)
                p.color=teal;p.textAlign=Paint.Align.CENTER;p.textSize=h*.23f;p.typeface=Typeface.create("sans-serif",Typeface.BOLD)
                c.drawText("?",w*.5f,h*.54f,p)
            } else {
                val left=w*.19f; val right=w*.81f;val base=h*.69f
                p.color=Color.rgb(192,184,165); c.drawRoundRect(left,base-h*.20f,right,base,w*.012f,w*.012f,p)
                p.color=Color.rgb(240,236,222)
                val doors=if(state.currentId=="gwanghwamun") 3 else 1
                repeat(doors) { index ->
                    val x=w*.5f+(index-(doors-1)/2f)*w*.15f
                    c.drawRoundRect(x-w*.045f,base-h*.145f,x+w*.045f,base,w*.045f,w*.045f,p)
                }
                for(level in 0..1) {
                    val y=base-h*.24f-level*h*.15f
                    p.color=Color.rgb(131,104,81);c.drawRect(w*.27f,y-h*.075f,w*.73f,y+h*.02f,p)
                    for(i in 0..4) line(w*(.29f+i*.105f),y-h*.065f,w*(.29f+i*.105f),y+h*.015f,Color.rgb(97,137,121),w*.015f)
                    val roof=Path().apply { moveTo(w*.15f,y+h*.01f);quadTo(w*.28f,y-h*.015f,w*.34f,y-h*.10f);lineTo(w*.66f,y-h*.10f);quadTo(w*.72f,y-h*.015f,w*.85f,y+h*.01f);quadTo(w*.5f,y+h*.065f,w*.15f,y+h*.01f) }
                    p.color=dark;c.drawPath(roof,p)
                }
                if(state.phase==CuratorPhase.PREDICT) {
                    p.color=Color.rgb(245,213,141);c.drawCircle(w*.78f,h*.24f,w*.085f,p)
                    p.color=dark;p.textAlign=Paint.Align.CENTER;p.textSize=h*.07f;c.drawText("?",w*.78f,h*.265f,p)
                }
                p.color=Color.rgb(108,133,124);p.textSize=h*.033f;p.textAlign=Paint.Align.CENTER
                c.drawText("모양을 단순화한 그림이에요",w*.5f,h*.79f,p)
            }
            val stage=when(state.phase) { CuratorPhase.PREDICT -> 0;CuratorPhase.WATCH -> 1;CuratorPhase.EXPLAIN -> 2;CuratorPhase.COMPARE,CuratorPhase.MEMORY,CuratorPhase.FINISHED -> 3;else -> -1 }
            line(w*.16f,h*.9f,w*.84f,h*.9f,pale,w*.012f)
            if(stage>0) line(w*.16f,h*.9f,w*(.16f+stage*.2267f),h*.9f,teal,w*.012f)
            val names=listOf("생각","관찰","이야기","발견")
            repeat(4) { i ->
                val x=w*(.16f+i*.2267f)
                p.color=if(i<=stage) teal else pale;c.drawCircle(x,h*.9f,w*.023f,p)
                p.textAlign=Paint.Align.CENTER;p.textSize=h*.043f;c.drawText(names[i],x,h*.985f,p)
            }
        }
    }
}
