package dev.changbak.explorer.domain

enum class CuratorPhase { READY, WAITING, PREDICT, WATCH, EXPLAIN, COMPARE, MEMORY, FINISHED }
enum class SeenStatus { UNKNOWN, SEEN, NOT_SEEN }
enum class Reflection(val label: String) { SAME("생각과 비슷했어"), DIFFERENT("생각과 달랐어"), UNSURE("아직 잘 모르겠어") }
data class CuratorPlace(val id: String, val name: String, val theme: String, val question: String,
    val guesses: List<String>, val observe: String, val explanation: String, val sourceTitle: String, val sourceUrl: String)
data class PlaceApproach(val placeId: String, val etaSeconds: Int, val passed: Boolean = false, val observable: Boolean = true)
data class CuratorFix(val routeId: String, val sequence: Long, val approaches: List<PlaceApproach>, val fresh: Boolean = true)
data class PlaceMemory(val placeId: String, val guess: String? = null, val seen: SeenStatus = SeenStatus.UNKNOWN,
    val reflection: Reflection? = null, val explained: Boolean = false)
data class CuratorState(val phase: CuratorPhase = CuratorPhase.READY, val routeId: String? = null,
    val sequence: Long = -1, val currentId: String? = null, val etaSeconds: Int? = null,
    val visits: List<PlaceMemory> = emptyList(), val deferred: Set<String> = emptySet(), val message: String = "",
    val routeValid: Boolean = true)
data class CuratorTurn(val state: CuratorState, val narration: String? = null)

/** Provider supplies ETA to each encounter, not ETA to the final destination. No sight detection claims. */
class RouteCurator(private val catalog: List<CuratorPlace>) {
    fun place(state: CuratorState) = catalog.firstOrNull { it.id == state.currentId }
    fun memory(state: CuratorState) = state.visits.firstOrNull { it.placeId == state.currentId }
    fun start() = CuratorState(phase = CuratorPhase.WAITING, message = "가는 길에서 만날 이야기를 기다리고 있어.")
    fun tick(state: CuratorState, fix: CuratorFix): CuratorTurn {
        if (!fix.fresh || (fix.routeId == state.routeId && fix.sequence <= state.sequence) || state.phase == CuratorPhase.READY || state.phase == CuratorPhase.FINISHED) return CuratorTurn(state)
        var next = state.copy(routeId = fix.routeId, sequence = fix.sequence, routeValid = true)
        val current = fix.approaches.firstOrNull { it.placeId == state.currentId }
        if (state.currentId != null && current == null && state.phase in setOf(CuratorPhase.PREDICT, CuratorPhase.WATCH)) {
            next = next.copy(phase = CuratorPhase.WAITING, currentId = null, etaSeconds = null,
                deferred = next.deferred + state.currentId, message = "길이 바뀌었어. 새 길에서 만날 곳을 다시 살펴볼게.")
        }
        if (current != null) {
            next = next.copy(etaSeconds = current.etaSeconds.coerceAtLeast(0))
            if (state.phase in setOf(CuratorPhase.PREDICT, CuratorPhase.WATCH)) {
                if (current.passed) return explain(next)
                if (current.etaSeconds in 0..30 && state.phase == CuratorPhase.PREDICT) {
                    val p = place(next) ?: return CuratorTurn(next)
                    val text = if (current.observable) "곧 ${p.name} 근처야. ${p.observe} 안 보이면 그냥 지나가도 좋아."
                        else "지금은 보기 어려운 구간이야. 지나간 뒤 이야기로 만나자."
                    return CuratorTurn(next.copy(phase = CuratorPhase.WATCH, message = text), text)
                }
            }
        }
        if (next.phase !in setOf(CuratorPhase.WAITING, CuratorPhase.MEMORY)) return CuratorTurn(next)
        val candidate = fix.approaches.filter { approach -> approach.observable && approach.etaSeconds in 31..300 && !approach.passed &&
            approach.placeId !in next.deferred && next.visits.none { it.placeId == approach.placeId } && catalog.any { it.id == approach.placeId } }
            .minByOrNull { it.etaSeconds } ?: return CuratorTurn(next)
        val p = catalog.first { it.id == candidate.placeId }
        val text = "약 ${((candidate.etaSeconds + 59)/60).coerceAtLeast(1)}분 뒤에 ${p.name} 근처를 지나갈 거야. ${p.question}"
        return CuratorTurn(next.copy(phase = CuratorPhase.PREDICT, currentId = p.id, etaSeconds = candidate.etaSeconds,
            visits = next.visits + PlaceMemory(p.id), message = text), text)
    }
    fun predict(state: CuratorState, guess: String): CuratorTurn {
        if (state.phase != CuratorPhase.PREDICT || guess.isBlank()) return CuratorTurn(state)
        val clean = guess.trim().take(160)
        val next = updateMemory(state) { it.copy(guess = clean) }
        val text = "그렇게 생각했구나. 가까이 가면 직접 살펴보자."
        return CuratorTurn(next.copy(message = text), text)
    }
    fun seen(state: CuratorState, seen: Boolean): CuratorTurn {
        if (state.phase != CuratorPhase.WATCH || !state.routeValid) return CuratorTurn(state)
        val next = updateMemory(state) { it.copy(seen = if (seen) SeenStatus.SEEN else SeenStatus.NOT_SEEN) }
        return if (seen) explain(next) else CuratorTurn(next.copy(message = "괜찮아. 지나가면 이야기로 들려줄게."), "괜찮아. 지나가면 이야기로 들려줄게.")
    }
    private fun explain(state: CuratorState): CuratorTurn {
        val p = place(state) ?: return CuratorTurn(state)
        if (memory(state)?.explained == true) return CuratorTurn(state)
        val text = (if (memory(state)?.seen == SeenStatus.SEEN) "네가 본 ${p.name} 이야기야. " else "${p.name} 근처를 지났어. 보지 못했어도 괜찮아. ") + p.explanation
        return CuratorTurn(updateMemory(state) { it.copy(explained = true) }.copy(phase = CuratorPhase.EXPLAIN, message = text), text)
    }
    fun afterExplanation(state: CuratorState): CuratorTurn {
        if (state.phase != CuratorPhase.EXPLAIN) return CuratorTurn(state)
        val text = if (memory(state)?.guess == null) "설명을 듣고 새롭게 알게 된 게 있어?" else "처음 생각했던 것과 비슷했어, 달랐어?"
        return CuratorTurn(state.copy(phase = CuratorPhase.COMPARE, message = text), text)
    }
    fun reflect(state: CuratorState, reflection: Reflection): CuratorTurn {
        if (state.phase != CuratorPhase.COMPARE) return CuratorTurn(state)
        val text = when (reflection) {
            Reflection.SAME -> "네 생각과 이어지는 점이 있었구나. 오늘 만난 이야기로 남겨둘게."
            Reflection.DIFFERENT -> "새로운 모습을 발견했구나. 생각이 달라진 것도 좋은 여행의 기억이야."
            Reflection.UNSURE -> "지금 정하지 않아도 괜찮아. 궁금했던 곳으로 남겨둘게."
        }
        return CuratorTurn(updateMemory(state) { it.copy(reflection = reflection) }.copy(phase = CuratorPhase.MEMORY, message = text), text)
    }
    fun skip(state: CuratorState): CuratorTurn {
        val id = state.currentId ?: return CuratorTurn(state)
        return CuratorTurn(state.copy(phase = CuratorPhase.WAITING, currentId = null, etaSeconds = null,
            deferred = state.deferred + id, message = "좋아. 편하게 밖을 보고 있어도 돼."))
    }
    fun finish(state: CuratorState) = CuratorTurn(state.copy(phase = CuratorPhase.FINISHED, message = "오늘 길에서 만난 이야기를 돌아볼까?"))
    fun navigationLost(state: CuratorState) = state.copy(routeValid = false)
    private fun updateMemory(state: CuratorState, change: (PlaceMemory) -> PlaceMemory) = state.copy(
        visits = state.visits.map { if (it.placeId == state.currentId) change(it) else it })
}

object CuratorCatalog {
    val places = listOf(
        CuratorPlace("sungnyemun", "숭례문", "도시를 드나들던 문", "옛날에는 왜 도시에도 커다란 문이 필요했을까?",
            listOf("도시를 지키려고", "사람들이 드나들려고", "아직 모르겠어"), "큰 지붕 아래 둥근 통로를 찾아볼래?",
            "숭례문은 옛 서울을 둘러싼 한양도성의 남쪽 문이야. 돌로 쌓은 부분 가운데 통로가 있고, 그 위에는 두 층의 건물이 있어. 옛날에는 밤에 문을 닫고 새벽에 다시 열었대.",
            "국가유산청 궁능유적본부", "https://royal.khs.go.kr/ROYAL/contents/R108010000.do"),
        CuratorPlace("gwanghwamun", "광화문", "궁궐의 첫 번째 문", "광화문 뒤에는 어떤 곳이 있을 것 같아?",
            listOf("궁궐이 있을 것 같아", "시장이 있을 것 같아", "아직 모르겠어"), "큰 문 뒤로 이어지는 공간을 살펴봐.",
            "광화문은 경복궁으로 들어가는 정문이야. 경복궁은 조선의 궁궐이었어. 숭례문이 도시의 문이라면, 광화문은 궁궐의 문이라는 차이가 있어.",
            "정부 정책브리핑 궁궐 이야기", "https://www.korea.kr/goNewsRes/attaches/2019.05/23/107_20170109_01IozeNoYDGJM000.pdf")
    )
}
