package dev.changbak.explorer

import android.app.Activity
import android.app.AlertDialog
import android.animation.ValueAnimator
import android.car.Car
import android.car.drivingstate.CarUxRestrictions
import android.car.drivingstate.CarUxRestrictionsManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import dev.changbak.explorer.audio.VoiceGuide
import dev.changbak.explorer.domain.*
import org.json.JSONArray
import org.json.JSONObject

/** The vehicle shell belongs to Pleos; only this app area is replaced. */
class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val engine = RouteCurator(CuratorCatalog.places)
    private var state = CuratorState()
    private lateinit var voice: VoiceGuide
    private lateinit var navi: CuratorNaviSource
    private var car: Car? = null
    private var restrictions: CarUxRestrictionsManager? = null
    private var connected = false
    private var restricted = true
    private var foreground = false
    private var demo = false
    private var playing = false
    private var demoTime = 0
    private var sequence = 0L
    private var mic = false
    private var status = "음성을 준비하고 있어요"
    private var naviStatus = "내비게이션 연결 전"
    private var live = false
    private var narrationGeneration = 0L
    private var cardGeneration = 0L
    private var dialog: AlertDialog? = null
    private var lastCard: List<Any?>? = null
    private lateinit var card: LinearLayout
    private lateinit var scene: CuratorSceneView
    private lateinit var badge: TextView
    private lateinit var placeName: TextView
    private lateinit var subline: TextView
    private var statusLabel: TextView? = null
    private val ink = Color.rgb(31,49,67)
    private val muted = Color.rgb(99,119,135)
    private val accent = Color.rgb(36,103,111)
    private val timer = object : Runnable {
        override fun run() {
            if (foreground && demo && playing && !restricted && dialog == null) {
                demoTime = (demoTime + 10).coerceAtMost(1000)
                feedDemo()
            }
            if (foreground) handler.postDelayed(this, 1000L)
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        voice = VoiceGuide(this, onState = { value -> runOnUiThread {
            status = when(value) { "speaking" -> "이야기를 듣는 중"; "listening" -> "네 생각을 듣고 있어"; else -> "말하지 않아도 괜찮아" }
            if (::voice.isInitialized && !voice.enabled) mic = false
            statusLabel?.text = status
        } }, onCommand = {}, onError = { value -> runOnUiThread { mic = false; status = value; statusLabel?.text = value } },
            onUtterance = { words -> runOnUiThread { if (mic && usable()) { quiet(); accept(words) } } })
        navi = CuratorNaviSource(this) { value -> runOnUiThread { naviStatus = value; if (live) render() } }
        buildLayout(); render()
        try {
            car = Car.createCar(this, handler, Car.CAR_WAIT_TIMEOUT_DO_NOT_WAIT) { service, ready -> runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                connected = ready
                if (ready) try {
                    restrictions = service.getCarManager(Car.CAR_UX_RESTRICTION_SERVICE) as CarUxRestrictionsManager
                    restrictions?.registerListener(::updateRestrictions)
                    restrictions?.currentCarUxRestrictions?.let(::updateRestrictions)
                } catch (_: Exception) { restricted = true; quiet() }
                else { restricted = true; quiet() }
                render()
            } }
        } catch (_: Exception) { restricted = true; render() }
    }
    private fun updateRestrictions(value: CarUxRestrictions) {
        restricted = value.isRequiresDistractionOptimization
        if (restricted) { playing = false; quiet(); dialog?.dismiss() }
        render()
    }
    override fun onResume() { super.onResume(); foreground = true; handler.removeCallbacks(timer); handler.post(timer); if (::card.isInitialized) render() }
    override fun onPause() {
        foreground = false; playing = false; quiet(); dialog?.dismiss(); navi.close()
        handler.removeCallbacks(timer); cardGeneration++; card.animate().cancel(); lastCard = null
        super.onPause()
    }
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null); narrationGeneration++; voice.release(); navi.close()
        runCatching { restrictions?.unregisterListener(); car?.disconnect() }; super.onDestroy()
    }
    private fun usable() = foreground && connected && !restricted && dialog == null
    private fun quiet() { narrationGeneration++; mic = false; if (::voice.isInitialized) voice.suspend() }
    private fun apply(turn: CuratorTurn) {
        if (!usable()) return
        val changed = turn.state != state
        state = turn.state
        if (changed) { render(); if (state.phase in setOf(CuratorPhase.MEMORY, CuratorPhase.FINISHED)) saveSummary() }
        val text = turn.narration ?: return
        quiet(); val token = narrationGeneration
        voice.speak(text) {
            if (token == narrationGeneration && usable() && state.phase == CuratorPhase.EXPLAIN)
                apply(engine.afterExplanation(state))
        }
    }
    private fun startDemo() {
        quiet(); navi.close(); live = false; demo = true; playing = true; demoTime = 0; sequence = 0
        state = engine.start(); lastCard = null; render(); feedDemo()
    }
    private fun feedDemo() {
        val fix = CuratorFix("seoul-demo", ++sequence, listOf(
            PlaceApproach("sungnyemun", 360-demoTime, passed = demoTime > 360),
            PlaceApproach("gwanghwamun", 900-demoTime, passed = demoTime > 900)))
        apply(engine.tick(state, fix))
        if (demoTime >= 1000) playing = false
    }
    private fun jump(seconds: Int) { quiet(); demoTime = seconds; feedDemo() }
    private fun accept(text: String) {
        if (!usable()) return
        val compact = text.replace(Regex("[\\s\\p{Z}\\p{P}]"), "")
        if (compact in setOf("쉬자","그만","그만할래","잠깐쉴래")) { playing = false; quiet(); status = "쉬는 중이에요"; render(); return }
        if (compact in setOf("다음","넘어가자","건너뛸래")) { apply(engine.skip(state)); return }
        when (state.phase) {
            CuratorPhase.PREDICT -> apply(engine.predict(state, text))
            CuratorPhase.WATCH -> when {
                Regex("안보|못봤|못보|안봤").containsMatchIn(compact) -> apply(engine.seen(state,false))
                Regex("보여|봤어|보인다|찾았").containsMatchIn(compact) -> apply(engine.seen(state,true))
                else -> { status = "보이면 ‘봤어’, 안 보이면 ‘안 보여’라고 알려줘"; statusLabel?.text = status }
            }
            CuratorPhase.COMPARE -> when {
                Regex("달라|달랐|다르|새로").containsMatchIn(compact) -> apply(engine.reflect(state,Reflection.DIFFERENT))
                Regex("비슷|같았|맞았").containsMatchIn(compact) -> apply(engine.reflect(state,Reflection.SAME))
                else -> apply(engine.reflect(state,Reflection.UNSURE))
            }
            else -> { status = "지금은 편하게 듣고 있어도 좋아"; statusLabel?.text = status }
        }
    }
    private fun listen() {
        if (!usable()) return
        if (mic) { quiet(); render(); return }
        quiet(); playing = false
        show(AlertDialog.Builder(this).setTitle("네 생각을 들려줘")
            .setMessage("확인을 누르면 이번 답변을 듣기 시작해요. 음성은 기기 안에서 처리하고 외부 AI로 보내지 않아요.")
            .setNegativeButton("나중에", null).setPositiveButton("이야기할게") { _, _ -> handler.post {
                if (usable()) { mic = voice.enableCommands(); status = if (mic) "네 생각을 듣고 있어" else "지금은 화면으로 골라줘"; render() }
            } }.create())
    }
    private fun dp(n: Int) = (n*resources.displayMetrics.density).toInt()
    private fun column() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun rounded(color: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(28).toFloat() }
    private fun label(text: String, size: Float, color: Int = ink, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); includeFontPadding = false; setLineSpacing(dp(5).toFloat(),1f)
        if (bold) typeface = Typeface.create("sans-serif-medium",Typeface.NORMAL)
    }
    private fun button(text: String, primary: Boolean = false, action: () -> Unit) = Button(this).apply {
        this.text = text; textSize = 24f; isAllCaps = false; setTextColor(if (primary) Color.WHITE else ink)
        background = rounded(if(primary) accent else Color.rgb(235,242,241)); minHeight = dp(72)
        setPadding(dp(16),dp(12),dp(16),dp(12)); setOnClickListener { if (usable()) action() }
    }
    private fun action(text: String, primary: Boolean = false, fn: () -> Unit) {
        card.addView(button(text,primary,fn),LinearLayout.LayoutParams(-1,dp(74)).apply { topMargin = dp(10) })
    }
    private fun gap(parent: LinearLayout,n: Int) { parent.addView(View(this),LinearLayout.LayoutParams(1,dp(n))) }
    private fun buildLayout() {
        val root = column().apply { setBackgroundColor(Color.rgb(245,248,247)); setPadding(dp(30),dp(24),dp(30),dp(24)) }
        val header = row(); val titles = column()
        titles.addView(label("가는 길이 이야기가 되는 시간",17f,muted)); gap(titles,6)
        titles.addView(label("길 위의 큐레이터",29f,ink,true))
        header.addView(titles,LinearLayout.LayoutParams(0,-2,1f))
        badge = label("시연 경로",18f,accent,true).also { header.addView(it,LinearLayout.LayoutParams(-2,-2).apply { marginEnd=dp(22) }) }
        header.addView(button("보호자") { parentMenu() },LinearLayout.LayoutParams(-2,dp(68)))
        root.addView(header); gap(root,24)
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val body = row().apply { gravity = Gravity.TOP }
        val left = column().apply { background = rounded(Color.rgb(226,238,233)); setPadding(dp(24),dp(24),dp(24),dp(28)); gravity=Gravity.CENTER_HORIZONTAL }
        subline = label("경로에서 만나는 발견",20f,accent,true).also { left.addView(it) }
        scene = CuratorSceneView(this).also { left.addView(it,LinearLayout.LayoutParams(-1,dp(290))) }
        placeName = label("어떤 곳을 만나게 될까?",31f,ink,true).also { left.addView(it) }
        gap(left,18); left.addView(label("미리 생각하고 → 만나고 → 다시 생각해요",19f,muted))
        body.addView(left,LinearLayout.LayoutParams(0,-2,.46f).apply { marginEnd=dp(22) })
        card = column().apply { background = rounded(Color.WHITE); setPadding(dp(30),dp(30),dp(30),dp(28)) }
        body.addView(card,LinearLayout.LayoutParams(0,-2,.54f)); scroll.addView(body)
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
    }
    private fun render() {
        if (!::card.isInitialized || isDestroyed) return
        badge.text = if(live) "내비게이션 연결 확인" else if(demo) "시연 경로 / 시간 10배" else "정차 시연"
        val place = engine.place(state)
        placeName.text = place?.name ?: "길에서 만날 이야기"
        subline.text = if (state.phase==CuratorPhase.FINISHED) "오늘 지나온 발견" else state.etaSeconds?.let { if(it>0) "이 지점까지 약 ${(it+59)/60}분" else "이 지점 근처를 지났어요" } ?: "경로에서 만나는 발견"
        scene.present(state, !restricted && foreground)
        val snapshot = listOf(state.phase,state.currentId,state.message,state.visits,restricted,connected,demo,live,playing,naviStatus,mic)
        if(snapshot==lastCard) return
        lastCard=snapshot; val generation=++cardGeneration
        card.animate().cancel()
        if(foreground && !restricted && card.childCount>0 && ValueAnimator.areAnimatorsEnabled()) {
            card.animate().alpha(0f).setDuration(130).withEndAction {
                if(generation==cardGeneration && foreground) { populate(); card.animate().alpha(1f).setDuration(260).withEndAction(null).start() }
            }.start()
        } else { card.alpha=1f; populate() }
    }
    private fun populate() {
        card.removeAllViews(); statusLabel=null
        if(!connected || restricted) {
            card.addView(label(if(!connected) "차량과 연결하고 있어요" else "지금은 쉬어가요",36f,ink,true)); gap(card,22)
            card.addView(label("차가 멈추면 이야기를 이어가요.",25f,muted)); return
        }
        if(live) {
            card.addView(label("내비게이션 연결",25f,accent,true)); gap(card,22); card.addView(label(naviStatus,30f)); gap(card,22)
            card.addView(label("명소별 경로와 통과 시점 연동은 준비 중이에요. 아래 시연에서 전체 흐름을 체험할 수 있어요.",23f,muted))
            action("시연 경로로 체험하기",true) { startDemo() }; return
        }
        if(state.phase==CuratorPhase.READY) {
            card.addView(label("지나칠 뻔한 곳에\n어떤 이야기가 있을까?",37f,ink,true)); gap(card,24)
            card.addView(label("약 5분 전 질문을 듣고,\n가까이 가면 직접 살펴봐요.",25f,muted)); gap(card,18)
            action("시연 여행 시작",true) { startDemo() }; return
        }
        val heading=when(state.phase) { CuratorPhase.PREDICT -> "01  먼저 상상해 보기"; CuratorPhase.WATCH -> "02  창밖에서 만나기"; CuratorPhase.EXPLAIN -> "03  장소의 이야기"; CuratorPhase.COMPARE -> "04  내 생각과 비교하기"; CuratorPhase.MEMORY -> "오늘의 발견"; CuratorPhase.FINISHED -> "오늘 만난 이야기"; else -> "다음 이야기를 기다려요" }
        card.addView(label(heading,21f,accent,true)); gap(card,22)
        val text=if(state.phase==CuratorPhase.PREDICT) engine.place(state)?.question ?: state.message else state.message
        card.addView(label(text,if(state.phase==CuratorPhase.EXPLAIN) 28f else 33f,ink,true)); gap(card,18)
        when(state.phase) {
            CuratorPhase.PREDICT -> {
                engine.memory(state)?.guess?.let { card.addView(label("네 생각: $it",22f,accent)); gap(card,12) }
                engine.place(state)?.guesses?.forEach { guess -> action(guess) { apply(engine.predict(state,guess)) } }
                action("내 말로 이야기하기",true) { listen() }
            }
            CuratorPhase.WATCH -> { action("봤어!",true) { apply(engine.seen(state,true)) }; action("안 보여") { apply(engine.seen(state,false)) } }
            CuratorPhase.EXPLAIN -> action("내 생각과 비교하기") { quiet(); apply(engine.afterExplanation(state)) }
            CuratorPhase.COMPARE -> { Reflection.entries.forEach { reflection -> action(reflection.label) { apply(engine.reflect(state,reflection)) } }; action("내 말로 이야기하기") { listen() } }
            CuratorPhase.MEMORY -> { memoryCard(engine.memory(state)); action("다음 이야기 기다리기",true) { playing=true; render(); feedDemo() } }
            CuratorPhase.FINISHED -> { state.visits.forEach { memoryCard(it) }; action("새 시연 여행",true) { startDemo() } }
            else -> { action(if(playing) "잠깐 쉬기" else "이어서 가기",true) { playing=!playing; render() } }
        }
        if(state.phase !in setOf(CuratorPhase.FINISHED,CuratorPhase.WAITING)) {
            gap(card,18); val small=row()
            small.addView(button("다시 듣기") { quiet(); voice.speak(state.message) },LinearLayout.LayoutParams(0,dp(68),1f))
            small.addView(button("넘어갈래") { quiet(); apply(engine.skip(state)) },LinearLayout.LayoutParams(0,dp(68),1f).apply { marginStart=dp(10) }); card.addView(small)
        }
        gap(card,18); statusLabel=label(status,18f,muted).also { card.addView(it) }
    }
    private fun memoryCard(memory: PlaceMemory?) {
        memory ?: return
        val p=CuratorCatalog.places.firstOrNull { it.id==memory.placeId } ?: return
        card.addView(label(p.name,25f,accent,true)); gap(card,8)
        val guess=memory.guess?.let { "처음 생각: $it\n" } ?: ""
        val observed=when(memory.seen) { SeenStatus.SEEN -> "직접 봤어"; SeenStatus.NOT_SEEN -> "보이지 않아 이야기로 만났어"; else -> "봤는지는 아직 말하지 않았어" }
        card.addView(label(guess+observed+"\n"+(memory.reflection?.label ?: "생각은 아직 남겨두었어"),21f,muted)); gap(card,18)
    }
    private fun show(next: AlertDialog) {
        if(!usable()) return
        quiet(); dialog=next
        next.setOnDismissListener { if(dialog===next) dialog=null }; next.show()
    }
    private fun parentMenu() {
        val items=arrayOf(if(playing) "시연 잠깐 멈추기" else "시연 이어서 재생", "시점 이동해서 확인", "말 대신 입력", "오늘 이야기 마치기", "설명 출처", "지난 시연 기억", "실제 내비게이션 연결 확인", "새 시연 여행")
        show(AlertDialog.Builder(this).setTitle("보호자 / 정차 시연").setItems(items) { _,i -> handler.post {
            when(i) {
                0 -> { if(demo) { playing=!playing; render() } }
                1 -> demoControls()
                2 -> textInput()
                3 -> { playing=false; apply(engine.finish(state)) }
                4 -> sources()
                5 -> previousSummary()
                6 -> { quiet(); playing=false; demo=false; live=true; state=engine.start(); render(); navi.connect() }
                7 -> startDemo()
            }
        } }.setNegativeButton("닫기",null).create())
    }
    private fun demoControls() {
        if(!demo) { startDemo(); return }
        val entries=arrayOf("숭례문 약 5분 전", "숭례문 가까이", "숭례문 통과", "광화문 약 5분 전", "광화문 가까이", "광화문 통과")
        show(AlertDialog.Builder(this).setTitle("시연 위치 신호").setItems(entries) { _,i -> handler.post {
            playing=false; jump(listOf(60,340,370,600,880,910)[i])
        } }.setNegativeButton("닫기",null).create())
    }
    private fun textInput() {
        playing=false
        val field=EditText(this).apply { hint="아이가 말할 법한 생각을 입력해 보세요"; textSize=23f; filters=arrayOf(android.text.InputFilter.LengthFilter(160)); importantForAutofill=View.IMPORTANT_FOR_AUTOFILL_NO }
        show(AlertDialog.Builder(this).setTitle("말 대신 입력하기").setView(field).setNegativeButton("닫기",null)
            .setPositiveButton("전하기") { _,_ -> handler.post { accept(field.text.toString()) } }.create())
    }
    private fun sources() {
        val text=CuratorCatalog.places.joinToString("\n\n") { "${it.name}\n${it.sourceTitle}\n${it.sourceUrl}" }
        show(AlertDialog.Builder(this).setTitle("설명 출처와 현재 범위").setMessage("$text\n\n역사 설명은 위 자료를 바탕으로 작성했어요. 시연 위치와 도착 시간은 가상 데이터이며 실제 시야를 감지하지 않아요. 실제 내비게이션은 목적지 조회까지만 연결되어 있어요.").setPositiveButton("닫기",null).create())
    }
    private fun saveSummary() {
        if(!demo || state.visits.isEmpty()) return
        val array=JSONArray()
        state.visits.forEach { memory ->
            val p=CuratorCatalog.places.firstOrNull { it.id==memory.placeId } ?: return@forEach
            array.put(JSONObject().put("id",p.id).put("guess",memory.guess?.let { if (it in p.guesses) it else "자유롭게 생각했어" } ?: "답하지 않았어")
                .put("seen",memory.seen.name).put("reflection",memory.reflection?.label ?: "아직 생각 중"))
        }
        getSharedPreferences("route_curator_v1",MODE_PRIVATE).edit().putString("demo_summary",array.toString()).apply()
    }
    private fun previousSummary() {
        val raw=getSharedPreferences("route_curator_v1",MODE_PRIVATE).getString("demo_summary",null)
        val text=runCatching {
            val array=JSONArray(raw ?: "[]")
            (0 until minOf(array.length(),10)).mapNotNull { index ->
                val item=array.getJSONObject(index); val p=CuratorCatalog.places.firstOrNull { it.id==item.optString("id") } ?: return@mapNotNull null
                "${p.name}\n처음 생각: ${item.optString("guess")}\n${item.optString("reflection")}"
            }.joinToString("\n\n")
        }.getOrDefault("").ifBlank { "아직 남긴 시연 기억이 없어요." }
        show(AlertDialog.Builder(this).setTitle("지난 시연에서 만난 곳").setMessage(text+"\n\n자유롭게 말한 문장과 음성은 저장하지 않아요.").setPositiveButton("닫기",null).create())
    }
}
