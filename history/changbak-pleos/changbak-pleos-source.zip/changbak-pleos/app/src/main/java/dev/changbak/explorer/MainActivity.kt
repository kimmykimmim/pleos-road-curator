package dev.changbak.explorer

import android.app.Activity
import android.app.AlertDialog
import android.car.Car
import android.car.drivingstate.CarUxRestrictions
import android.car.drivingstate.CarUxRestrictionsManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.*
import dev.changbak.explorer.audio.MissionCommand
import dev.changbak.explorer.audio.VoiceGuide
import dev.changbak.explorer.domain.*

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var storage: SessionStore
    private lateinit var state: MissionState
    private lateinit var voice: VoiceGuide
    private val undo = ArrayDeque<MissionState>()
    private var active = false
    private var foreground = false
    private var armed = false
    private var carReady = false
    private var restricted = true
    private var car: Car? = null
    private var restrictionManager: CarUxRestrictionsManager? = null
    private var voiceStatus = "음성 안내 준비 중"
    private var statusView: TextView? = null
    private var hintTask: Runnable? = null
    private var generation = 0
    private var hintUsed = false
    private var notice = ""
    private var lastAction = 0L
    private val blue = Color.rgb(23, 103, 250)
    private val ink = Color.rgb(25, 36, 53)
    private val muted = Color.rgb(98, 114, 136)
    private val background = Color.rgb(246, 248, 252)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        storage = SessionStore(this)
        state = storage.restore()
        voice = VoiceGuide(this,
            onState = { label -> runOnUiThread {
                voiceStatus = when (label) {
                    "speaking" -> "미션을 들려주고 있어요"
                    "listening" -> "듣고 있어요"
                    "waiting" -> "잠시 기다려요"
                    "processing" -> "말을 알아듣고 있어요"
                    "idle" -> "준비됐어요"
                    "paused", "stopped" -> "마이크가 꺼져 있어요"
                    else -> if (label.matches(Regex("[a-z_-]+"))) "버튼으로도 답할 수 있어요" else label
                }
                statusView?.text = voiceStatus
                if (::voice.isInitialized && armed && !voice.enabled) {
                    armed = false
                    cancelPending()
                    render()
                }
            } },
            onCommand = { command -> runOnUiThread { receive(command) } },
            onError = { message -> runOnUiThread {
                voiceStatus = message
                statusView?.text = message
                if (::voice.isInitialized && !voice.enabled) armed = false
            } },
        )
        render()
        connectCar()
    }

    private fun connectCar() {
        try {
            car = Car.createCar(this, handler, Car.CAR_WAIT_TIMEOUT_DO_NOT_WAIT) { connectedCar, ready ->
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    carReady = ready
                    if (ready) {
                        try {
                            restrictionManager = connectedCar.getCarManager(Car.CAR_UX_RESTRICTION_SERVICE) as CarUxRestrictionsManager
                            restrictionManager?.registerListener { updateRestrictions(it) }
                            restrictionManager?.currentCarUxRestrictions?.let(::updateRestrictions)
                        } catch (error: Exception) {
                            carReady = false; restricted = true; pauseSession()
                            Log.w("WindowExplorer", "Vehicle restriction service unavailable", error)
                        }
                    } else { restricted = true; pauseSession() }
                    render()
                }
            }
        } catch (error: Exception) {
            carReady = false; restricted = true
            Log.w("WindowExplorer", "Vehicle connection unavailable", error)
            render()
        }
    }

    private fun updateRestrictions(value: CarUxRestrictions) {
        val blocked = value.isRequiresDistractionOptimization
        carReady = true
        if (blocked && !restricted) pauseSession()
        restricted = blocked
        render()
    }

    override fun onResume() { super.onResume(); foreground = true; render() }
    override fun onPause() {
        foreground = false
        pauseSession()
        storage.save(state)
        super.onPause()
    }
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        voice.release()
        runCatching { restrictionManager?.unregisterListener(); car?.disconnect() }
        super.onDestroy()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun shape(color: Int, radius: Int = 24) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun column() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun text(value: String, size: Float, color: Int = ink, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        includeFontPadding = false
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setLineSpacing(dp(5).toFloat(), 1f)
    }
    private fun gap(parent: LinearLayout, height: Int) { parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height))) }
    private fun button(label: String, primary: Boolean = false, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 25f; isAllCaps = false
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(if (primary) Color.WHITE else ink)
        background = shape(if (primary) blue else Color.rgb(237, 242, 249), 20)
        minimumHeight = dp(78); minHeight = dp(78); minimumWidth = dp(100)
        setPadding(dp(20), dp(10), dp(20), dp(10))
        setOnClickListener { action() }
    }
    private fun addButton(parent: LinearLayout, button: Button, weight: Float = 1f) {
        parent.addView(button, LinearLayout.LayoutParams(0, dp(82), weight).apply { marginEnd = dp(12) })
    }

    private fun render() {
        if (isDestroyed || !::state.isInitialized) return
        statusView = null
        val wide = resources.configuration.screenWidthDp >= 900
        val root = column().apply {
            setBackgroundColor(this@MainActivity.background)
            setPadding(dp(if (wide) 40 else 24), dp(24), dp(if (wide) 40 else 24), dp(24))
        }
        val header = row()
        header.addView(text("창밖 탐험", 29f, ink, true), LinearLayout.LayoutParams(0, -2, 1f))
        if (active) {
            header.addView(button("다시 듣기") { speakMission() }, LinearLayout.LayoutParams(-2, dp(70)).apply { marginEnd = dp(12) })
            header.addView(button("쉬기") { pauseSession(); render() }, LinearLayout.LayoutParams(-2, dp(70)).apply { marginEnd = dp(12) })
        }
        header.addView(button("설정") { parentSettings() }, LinearLayout.LayoutParams(-2, dp(70)))
        root.addView(header)
        gap(root, 26)
        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        val body = LinearLayout(this).apply { orientation = if (wide) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL }
        scroll.addView(body, FrameLayout.LayoutParams(-1, -1))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        if (wide) {
            val scene = column().apply {
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(28), dp(40), dp(28), dp(28))
                background = shape(Color.rgb(233, 241, 251), 32)
            }
            scene.addView(text(state.context.displayName, 24f, muted))
            scene.addView(WindowSceneView(this, state.context).apply { importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO }, LinearLayout.LayoutParams(-1, dp(350)))
            gap(scene, 20)
            scene.addView(text(if (active) "창밖을 봐요" else "창밖에서 만나는 발견", 30f, ink, true).apply { gravity = Gravity.CENTER })
            gap(scene, 14)
            scene.addView(text("편하게 보이는 것부터", 23f, muted))
            if (state.discoveries.isNotEmpty()) {
                gap(scene, 40)
                scene.addView(text("내가 발견한 것", 20f, muted))
                gap(scene, 12)
                state.discoveries.takeLast(3).forEach { discovery ->
                    scene.addView(text(discovery.label, 22f, ink).apply { setPadding(0, dp(6), 0, dp(6)) })
                }
            }
            body.addView(scene, LinearLayout.LayoutParams(0, -1, 0.38f).apply { marginEnd = dp(28) })
        }
        val card = column().apply {
            background = shape(Color.WHITE, 32)
            setPadding(dp(if (wide) 44 else 28), dp(38), dp(if (wide) 44 else 28), dp(32))
        }
        body.addView(card, if (wide) LinearLayout.LayoutParams(0, -1, 0.62f) else LinearLayout.LayoutParams(-1, -1))
        when {
            !carReady -> {
                card.addView(text("차량 연결을 확인해요", 40f, ink, true))
                gap(card, 24)
                card.addView(text("Pleos 가상 차량에서 사용할 수 있어요.", 27f, muted))
            }
            restricted -> {
                card.addView(text("잠깐 쉬어가요", 42f, ink, true))
                gap(card, 26)
                card.addView(text("차가 멈추면 다시 시작할 수 있어요.", 30f, muted))
            }
            !active -> drawRest(card)
            else -> drawMission(card)
        }
        setContentView(root)
    }

    private fun drawRest(card: LinearLayout) {
        val resume = state.current != null
        card.addView(text(if (resume) "잠깐 쉬는 중" else "창밖엔 뭐가 있을까?", 43f, ink, true))
        gap(card, 24)
        card.addView(text(if (resume) "준비되면 이어서 해요." else "미션을 듣고, 창밖에서 찾아봐요.", 30f, muted))
        gap(card, 40)
        if (resume) {
            card.addView(text(state.current!!.label, 26f, blue, true))
            gap(card, 24)
        } else {
            card.addView(WindowSceneView(this, state.context).apply { importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO }, LinearLayout.LayoutParams(-1, dp(220)))
            gap(card, 24)
        }
        card.addView(button(if (resume) "이어서 탐험" else "탐험 시작", true) { startSession() }, LinearLayout.LayoutParams(-1, dp(96)))
        gap(card, 24)
        card.addView(text("소리로 안내해 줄게요", 23f, muted))
    }

    private fun drawMission(card: LinearLayout) {
        val mission = state.current ?: return
        card.addView(text(if (mission.kind == MissionKind.DETAIL) "한 번 더 관찰" else "오늘의 미션", 22f, blue, true))
        gap(card, 16)
        card.addView(text(mission.label, 41f, ink, true))
        gap(card, 22)
        card.addView(text(mission.prompt, 31f, ink))
        gap(card, 28)
        if (notice.isNotEmpty()) {
            card.addView(text(notice, 23f, muted))
            gap(card, 22)
        }
        val main = row()
        if (mission.kind == MissionKind.CHANGE) {
            addButton(main, button("달라졌어", true) { advance(MissionResult.FOUND) })
            addButton(main, button("비슷해") { advance(MissionResult.SAME) })
        } else {
            addButton(main, button(if (mission.kind == MissionKind.DETAIL) "살펴봤어" else "찾았어!", true) { advance(MissionResult.FOUND) })
        }
        card.addView(main)
        gap(card, 14)
        val alternatives = row()
        addButton(alternatives, button("안 보여") { advance(MissionResult.SKIP) })
        addButton(alternatives, button("지나갔어") { advance(MissionResult.CHANGED) })
        card.addView(alternatives)
        gap(card, 26)
        val tools = row()
        addButton(tools, button(if (armed) "마이크 끄기" else "말로 답하기") { toggleVoice() }, 1.4f)
        addButton(tools, button("힌트") { showHint() }, 0.8f)
        if (undo.isNotEmpty()) addButton(tools, button("되돌리기") { undoLast() }, 1f)
        card.addView(tools)
        gap(card, 18)
        statusView = text(voiceStatus, 20f, muted).also { card.addView(it) }
    }

    private fun startSession() {
        if (!foreground || restricted || !carReady) return
        if (state.current == null) state = MissionEngine.advance(state)
        active = true; armed = false; notice = ""; hintUsed = false
        storage.save(state); render(); speakMission()
    }

    private fun cancelPending() {
        generation++
        hintTask?.let(handler::removeCallbacks); hintTask = null
    }

    private fun pauseSession() {
        cancelPending(); active = false; armed = false
        if (::voice.isInitialized) voice.suspend()
    }

    private fun speakMission() {
        if (!active || !foreground || restricted) return
        val mission = state.current ?: return
        cancelPending()
        val token = generation
        voice.speak(mission.prompt) {
            if (token == generation && active && foreground && !restricted) scheduleHint(token)
        }
        // VoiceGuide waits for the completed announcement before opening the microphone.
        if (armed) voice.enableCommands()
    }

    private fun scheduleHint(token: Int) {
        if (!storage.gentleHint || hintUsed) return
        hintTask = Runnable {
            if (token == generation && active && foreground && !restricted && !hintUsed) showHint()
        }.also { handler.postDelayed(it, 25_000) }
    }

    private fun showHint() {
        if (!active || restricted || !foreground) return
        cancelPending(); hintUsed = true
        notice = state.current?.hint ?: return
        render(); voice.speak(notice)
        if (armed) voice.enableCommands()
    }

    private fun advance(result: MissionResult) {
        if (!active || restricted || !foreground) return
        // Ignore a duplicate release/tap from the same instant; never count a timeout as a result.
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastAction < 500) return
        lastAction = now
        undo.addLast(state)
        while (undo.size > 10) undo.removeFirst()
        state = MissionEngine.advance(state, result)
        hintUsed = false; notice = ""
        storage.save(state)
        Log.i("WindowExplorer", "Mission transition: $result -> ${state.current?.id}")
        render(); speakMission()
    }

    private fun undoLast() {
        if (!active || undo.isEmpty() || restricted) return
        state = undo.removeLast(); hintUsed = false; notice = ""
        storage.save(state); render(); speakMission()
    }

    private fun receive(command: MissionCommand) {
        if (!active || !armed || !foreground || restricted) return
        when (command) {
            MissionCommand.FOUND -> advance(MissionResult.FOUND)
            MissionCommand.SKIP -> advance(MissionResult.SKIP)
            MissionCommand.DIFFERENT -> advance(if (state.current?.kind == MissionKind.CHANGE) MissionResult.FOUND else MissionResult.CHANGED)
            MissionCommand.CHANGED -> advance(MissionResult.CHANGED)
            MissionCommand.SAME -> if (state.current?.kind == MissionKind.CHANGE) advance(MissionResult.SAME) else {
                voice.speak("찾았다면 찾았어, 보이지 않으면 안 보여라고 말해 줘."); if (armed) voice.enableCommands()
            }
            MissionCommand.HINT -> showHint()
            MissionCommand.REPEAT -> speakMission()
            MissionCommand.PAUSE -> { pauseSession(); render() }
            MissionCommand.UNDO -> if (undo.isNotEmpty()) undoLast() else { voice.speak("아직 되돌릴 미션이 없어."); if (armed) voice.enableCommands() }
        }
    }

    private fun toggleVoice() {
        if (armed) {
            armed = false; voice.suspend(); voiceStatus = "마이크가 꺼져 있어요"; render(); return
        }
        cancelPending(); voice.suspend()
        AlertDialog.Builder(this)
            .setTitle("말로 답할까요?")
            .setMessage("마이크가 켜지면 “찾았어”, “안 보여”, “지나갔어”라고 말할 수 있어요.\n\n음성은 차량 안에서 처리하며 앱에 녹음이나 말한 문장을 저장하지 않아요. 쉬기나 앱 종료 시 마이크가 꺼져요.")
            .setNegativeButton("버튼으로 할게요") { _, _ -> voiceStatus = "버튼으로 답할 수 있어요"; render() }
            .setPositiveButton("말로 답하기") { _, _ ->
                if (active && foreground && !restricted) {
                    armed = voice.enableCommands()
                    render()
                }
            }.show()
    }

    private fun parentSettings() {
        pauseSession(); render()
        val panel = column().apply { setPadding(dp(28), dp(12), dp(28), dp(12)) }
        panel.addView(text("지금 주변 풍경", 24f, ink, true))
        val environments = Environment.entries
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, environments.map { it.displayName })
            setSelection(state.context.ordinal)
        }
        panel.addView(spinner, LinearLayout.LayoutParams(-1, dp(64)))
        val hint = Switch(this).apply { text = "잠시 기다린 뒤 힌트 한 번"; textSize = 20f; isChecked = storage.gentleHint; minHeight = dp(64) }
        panel.addView(hint)
        gap(panel, 16)
        panel.addView(text("풍경은 보호자가 선택해요. 발견 기록은 아이의 답변을 담아요.", 19f, muted))
        gap(panel, 12)
        panel.addView(text("${voice.engineLabel}\n차량의 주행 중 사용 제한을 따라요.", 17f, muted))
        AlertDialog.Builder(this).setTitle("보호자 설정").setView(panel)
            .setNegativeButton("닫기", null)
            .setNeutralButton("새로 탐험") { _, _ ->
                AlertDialog.Builder(this).setTitle("새로 시작할까요?")
                    .setMessage("이 기기에 저장된 발견 기록을 비우고 처음부터 시작해요.")
                    .setNegativeButton("취소", null)
                    .setPositiveButton("새로 시작") { _, _ ->
                        state = MissionEngine.create(state.context); undo.clear(); notice = ""; storage.save(state); render()
                    }.show()
            }
            .setPositiveButton("적용") { _, _ ->
                storage.gentleHint = hint.isChecked
                val selected = environments[spinner.selectedItemPosition]
                if (selected != state.context) {
                    state = if (state.current == null) MissionEngine.create(selected) else MissionEngine.setContext(state, selected)
                    undo.clear(); notice = ""; hintUsed = false
                }
                storage.save(state); render()
            }.show()
    }
}
