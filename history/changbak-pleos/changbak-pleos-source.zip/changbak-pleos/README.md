# 창밖 탐험 — Pleos Android 프로토타입

6~8세 아이가 짧은 미션을 듣고 실제 창밖을 관찰하는 앱입니다. 차량의 운전 화면과 공조 영역은 Pleos가 표시하고, 이 앱은 오른쪽 앱 영역에만 나타납니다.

## 사용 흐름

1. **탐험 시작**을 누릅니다.
2. 짧은 미션을 듣고 편하게 보이는 창밖을 살펴봅니다.
3. **찾았어!**를 누르면 같은 대상의 다른 특징을 한 번 더 살펴봅니다.
4. **살펴봤어**를 누르면 다음 미션으로 넘어갑니다.

- **안 보여**: 다른 미션을 줍니다. 연속 두 번이면 더 쉬운 관찰을 우선합니다.
- **지나갔어**: 성공으로 기록하지 않고 새로운 미션으로 바꿉니다.
- **비슷해**: 변화 관찰 미션에서만 나타납니다. 달라지지 않아도 유효한 답입니다.
- **되돌리기**: 직전 답변을 되돌립니다.
- **쉬기**: 음성, 마이크, 예약된 힌트를 멈춥니다.
- **말로 답하기**: 앱 안의 설명을 확인하고 직접 켠 경우에만 마이크를 사용합니다.

## 구현 범위

- 기존 웹 프로토타입의 한국어 기본 미션 22개와 후속 관찰 문구를 옮겼습니다.
- 점수, 제한 시간, 실패 판정은 없습니다. 25초 후 선택적 힌트가 한 번 나옵니다.
- 미션 선택과 발견 기록 저장은 인터넷 없이 동작합니다.
- 발견 기록은 아이의 자기 보고입니다. 카메라, 시선, GPS로 발견 여부를 판정하지 않습니다.
- 보호자 설정에서 두루 살피기 / 도시 / 자연 / 터널 / 밤을 선택합니다. 실제 풍경 자동 인식은 구현하지 않았습니다.
- 현재 미션과 발견 목록은 기기에 저장됩니다. 다시 열면 쉬는 상태로 복원됩니다.
- 녹음과 실제 음성 인식 문장은 앱에 저장하지 않습니다. 계정이나 API 키가 필요하지 않습니다.

## Pleos 연결

- Pleos TextToSpeech / SpeechToText 3.3.1을 ON_DEVICE [기기 내부 처리] 방식으로 사용합니다.
- 음성 안내가 끝난 뒤 최소 600ms 후 듣기를 시작합니다.
- 사용자가 응답하지 않아도 미션을 실패 처리하지 않습니다. 듣기 재시도를 제한하고 버튼을 유지합니다.
- 음성 서비스 초기화가 실패하면 버튼으로 계속 사용할 수 있습니다.
- Pleos 안내 서비스를 사용할 수 없을 때는 설치된 오프라인 한국어 Android 음성을 시도합니다. 한국어 음성이 없으면 소리 없이 버튼으로 진행합니다.
- 앱이 배경으로 이동하거나 차량이 사용을 제한하면 자동으로 쉽니다. 재진입으로 마이크를 자동 재개하지 않습니다.
- CarUxRestrictions [차량이 알려 주는 사용 제한]을 따릅니다. 주행 제한 우회 선언은 넣지 않았습니다. 현재 버전은 정차 상태의 시연용이며, 실제 주행 중 탑승자용 제공 방식은 Pleos 정책과 표시 위치를 별도로 검토해야 합니다.
- 실제 차량에서 음성 첫 음절, 소음 속 인식률, 아이의 발화를 검증해야 합니다. Android 음성 대체 경로에는 앞부분 180ms 묵음을 적용했고, Pleos SDK의 직접 출력 경로는 실기기 검증이 남아 있습니다.

## Android Studio에서 이어서 만들기

1. Android Studio에서 **Open**을 선택하고 이 폴더를 엽니다.
2. 프로젝트 동기화가 끝날 때까지 기다립니다.
3. 기기 목록에서 **Pleos Connect v2.1.0**을 선택합니다.
4. **Run ▶**을 누릅니다.

환경은 Android API 34, Build Tools 36.0.0, AGP 9.1.0, Gradle 9.3.1입니다. Java 17 이상이 필요하며 이 PC에서는 JDK 21로 빌드했습니다. `local.properties`의 SDK 경로는 이 PC용이며 다른 PC에서는 Android Studio가 다시 설정해야 합니다.

## 검증

- `testDebugUnitTest`: 미션 선택과 기록 테스트 15개, 한국어 짧은 명령 파서 테스트 5개.
- `assembleDebug`: Android 설치 파일 생성.
- 테스트의 범위는 순수 로직입니다. 실제 마이크 인식률이나 차량 주행 중 사용 승인을 의미하지 않습니다.

## 주요 파일

- `app/src/main/java/dev/changbak/explorer/MainActivity.kt`: 화면과 진행 흐름
- `app/src/main/java/dev/changbak/explorer/domain/MissionEngine.kt`: 미션 선택과 응답 처리
- `app/src/main/java/dev/changbak/explorer/audio/VoiceGuide.kt`: Pleos 음성과 중단 처리
- `app/src/main/java/dev/changbak/explorer/SessionStore.kt`: 기기 내부 저장

## 공식 문서

- [Pleos 개발 시작](https://document.pleos.ai/docs/pleos-only/getting-started)
- [Pleos 에뮬레이터 설정](https://document.pleos.ai/docs/connect/guide/getting-started/application-development/setup-connect-sdk-emulator)
- [차량 앱 화면 구조](https://document.pleos.ai/docs/pleos-only/vehicle-app-planning-guide/app-structure-screen-model)
- [주행 중 사용 제한](https://document.pleos.ai/docs/pleos-only/vehicle-app-developer-guide/driving-restriction-development-guide)
- [Pleos 음성 안내](https://document.pleos.ai/en/docs/pleos-only/connect-sdk-pleos/TextToSpeech/intro)
- [Pleos 음성 인식](https://document.pleos.ai/en/docs/pleos-only/connect-sdk-pleos/SpeechToText/intro)
