package dev.changbak.explorer

import android.app.Activity
import android.app.AlertDialog
import android.car.Car
import android.car.drivingstate.CarUxRestrictions
import android.car.drivingstate.CarUxRestrictionsManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import dev.changbak.explorer.audio.VoiceGuide
import dev.changbak.explorer.domain.*

/** Pleos owns the driving view and climate bar. This Activity occupies only the app area. */
class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var store: CloudStore
    private lateinit var state: CloudState
    private lateinit var voice: VoiceGuide
    private val undo = ArrayDeque<CloudState>()
    private var foreground = false
    private var armed = false
    private var voiceConsent = false
    private var carReady = false
    private var restricted = true
    private var car: Car? = null
    private var restrictions: CarUxRestrictionsManager? = null
    private var reply = ""
    private var voiceStatus = "마이크는 눌렀을 때 켜져요"
    private var statusView: TextView? = null
    private var micButton: Button? = null
    private var dialog: AlertDialog? = null
    private val blue = Color.rgb(37, 105, 235)
    private val ink = Color.rgb(33, 53, 79)
    private val muted = Color.rgb(103, 124, 150)
    private val pageColor = Color.rgb(246, 249, 254)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = CloudStore(this)
        state = store.restore()
        voice = VoiceGuide(this, onState = { label -> runOnUiThread {
            voiceStatus = when (label) {
                "speaking" -> "친구의 이야기를 듣는 중"
                "listening" -> "듣고 있어요"
                "starting" -> "소리를 준비하고 있어요"
                "quiet" -> "다시 말하고 싶으면 마이크를 눌러요"
                else -> "천천히, 창밖을 살펴봐요"
            }
            if (::voice.isInitialized && !voice.enabled) armed = false
            statusView?.text = voiceStatus
            updateMicLabel()
        } }, onCommand = {}, onError = { message -> runOnUiThread {
            voiceStatus = message
            if (::voice.isInitialized && !voice.enabled) armed = false
            statusView?.text = message
            updateMicLabel()
        } }, onUtterance = { words -> runOnUiThread {
            if (foreground && armed && playable() && dialog == null) acceptWords(words)
        } })
        render()
        connectCar()
    }

    private fun connectCar() {
        try {
            car = Car.createCar(this, handler, Car.CAR_WAIT_TIMEOUT_DO_NOT_WAIT) { connected, ready -> runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                carReady = ready
                if (ready) try {
                    restrictions = connected.getCarManager(Car.CAR_UX_RESTRICTION_SERVICE) as CarUxRestrictionsManager
                    restrictions?.registerListener(::updateRestrictions)
                    restrictions?.currentCarUxRestrictions?.let(::updateRestrictions)
                } catch (error: Exception) {
                    carReady = false; restricted = true; backgroundPause()
                    Log.w("CloudFriends", "Vehicle connection unavailable", error)
                } else { restricted = true; backgroundPause() }
                render()
            } }
        } catch (error: Exception) {
            carReady = false; restricted = true
            Log.w("CloudFriends", "Vehicle API unavailable", error)
            render()
        }
    }

    private fun updateRestrictions(value: CarUxRestrictions) {
        carReady = true
        restricted = value.isRequiresDistractionOptimization
        if (restricted) { dialog?.dismiss(); backgroundPause() }
        render()
    }
    override fun onResume() { super.onResume(); foreground = true; render() }
    override fun onPause() {
        foreground = false; voiceConsent = false
        dialog?.dismiss(); backgroundPause()
        super.onPause()
    }
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        voice.release()
        runCatching { restrictions?.unregisterListener(); car?.disconnect() }
        super.onDestroy()
    }
    private fun backgroundPause() {
        quiet()
        if (::state.isInitialized && state.phase == CloudPhase.WATCHING) state = state.copy(phase = CloudPhase.RESTING)
        if (::store.isInitialized) store.save(state)
    }
    private fun playable() = foreground && carReady && !restricted && state.phase == CloudPhase.WATCHING
    private fun quiet() { armed = false; if (::voice.isInitialized) voice.suspend() }
    private fun updateMicLabel() { micButton?.text = if (armed) "마이크 끄기" else "이야기하기" }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int = 24) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun column() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun label(value: String, size: Float, color: Int = ink, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); includeFontPadding = false
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setLineSpacing(dp(5).toFloat(), 1f)
    }
    private fun gap(parent: LinearLayout, amount: Int) = parent.addView(View(this), LinearLayout.LayoutParams(1, dp(amount)))
    private fun button(value: String, primary: Boolean = false, action: () -> Unit) = Button(this).apply {
        text = value; textSize = 25f; isAllCaps = false
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(if (primary) Color.WHITE else ink)
        background = rounded(if (primary) blue else Color.rgb(235, 242, 252), 22)
        minimumHeight = dp(76); minHeight = dp(76)
        setPadding(dp(22), dp(12), dp(22), dp(12))
        setOnClickListener { action() }
    }
    private fun fullButton(parent: LinearLayout, value: String, primary: Boolean = false, action: () -> Unit): Button {
        return button(value, primary, action).also { parent.addView(it, LinearLayout.LayoutParams(-1, dp(86))) }
    }
    private fun pair(parent: LinearLayout, first: Button, second: Button) {
        val actions = row()
        actions.addView(first, LinearLayout.LayoutParams(0, dp(80), 1f).apply { marginEnd = dp(12) })
        actions.addView(second, LinearLayout.LayoutParams(0, dp(80), 1f))
        parent.addView(actions)
    }

    private fun render() {
        if (isDestroyed || !::state.isInitialized) return
        micButton = null; statusView = null
        val wide = resources.configuration.screenWidthDp >= 900
        val root = column().apply {
            setBackgroundColor(pageColor)
            setPadding(dp(if (wide) 40 else 24), dp(24), dp(if (wide) 40 else 24), dp(24))
        }
        val header = row()
        val brand = column()
        brand.addView(label("창밖 탐험", 17f, muted)); gap(brand, 7)
        brand.addView(label("구름 친구", 29f, ink, true))
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        if (state.phase == CloudPhase.WATCHING || state.phase == CloudPhase.RESTING) {
            header.addView(button("여행 마치기") { if (foreground && !restricted) applyTurn(CloudEngine.finish(state)) },
                LinearLayout.LayoutParams(-2, dp(70)).apply { marginEnd = dp(12) })
        }
        header.addView(button("보호자") { if (!restricted && carReady) parentMenu() }, LinearLayout.LayoutParams(-2, dp(70)))
        root.addView(header); gap(root, 28)
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val body = LinearLayout(this).apply { orientation = if (wide) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL }
        scroll.addView(body, FrameLayout.LayoutParams(-1, -1))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val reveal = state.phase == CloudPhase.KEEPSAKE
        if (wide) {
            val sky = column().apply {
                gravity = Gravity.CENTER_HORIZONTAL
                background = rounded(Color.rgb(232, 243, 255), 34)
                setPadding(dp(24), dp(36), dp(24), dp(26))
            }
            sky.addView(label(if (reveal) "우리 여행의 한 장" else "오늘, 같은 하늘 아래", 23f, muted))
            sky.addView(CloudFriendView(this, state.friend, reveal).apply { importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO },
                LinearLayout.LayoutParams(-1, dp(400)))
            gap(sky, 16)
            sky.addView(label(if (reveal) friendTitle(state.friend) else "천천히 바라봐도 괜찮아", 29f, ink, true).apply { gravity = Gravity.CENTER })
            gap(sky, 14)
            sky.addView(label(if (reveal) "네가 상상한 구름 친구" else "친구의 모습은 여행 끝에 만나요", 21f, muted).apply { gravity = Gravity.CENTER })
            body.addView(sky, LinearLayout.LayoutParams(0, -1, 0.43f).apply { marginEnd = dp(28) })
        }
        val card = column().apply {
            background = rounded(Color.WHITE, 34)
            setPadding(dp(if (wide) 42 else 26), dp(40), dp(if (wide) 42 else 26), dp(32))
        }
        body.addView(card, if (wide) LinearLayout.LayoutParams(0, -1, 0.57f) else LinearLayout.LayoutParams(-1, -1))
        when {
            !carReady -> { card.addView(label("차량과 연결하고 있어요", 39f, ink, true)); gap(card, 24); card.addView(label("잠시만 기다려 주세요.", 28f, muted)) }
            restricted -> { card.addView(label("지금은 쉬어가요", 43f, ink, true)); gap(card, 24); card.addView(label("차가 멈추면 이어서 만나요.", 29f, muted)) }
            state.phase == CloudPhase.WELCOME -> welcome(card, wide)
            state.phase == CloudPhase.WATCHING -> watching(card)
            state.phase == CloudPhase.RESTING -> resting(card)
            else -> keepsake(card, state, wide)
        }
        setContentView(root)
    }

    private fun welcome(card: LinearLayout, wide: Boolean) {
        card.addView(label("오늘은 어떤 친구를\n만나게 될까?", 44f, ink, true)); gap(card, 24)
        card.addView(label("마음에 드는 구름이 있으면\n뭐처럼 보이는지 알려줘.", 29f, muted)); gap(card, 32)
        if (!wide) { card.addView(CloudFriendView(this), LinearLayout.LayoutParams(-1, dp(190))); gap(card, 18) }
        fullButton(card, "같이 놀자", true) { if (foreground && !restricted) applyTurn(CloudEngine.start(state)) }
        gap(card, 20); card.addView(label("한마디만 해도 좋아요", 22f, muted))
    }
    private fun watching(card: LinearLayout) {
        card.addView(label(if (state.friend == null) "첫 만남을 기다리는 중" else "네가 들려준 구름", 22f, blue, true)); gap(card, 16)
        card.addView(label(if (state.friend == null) "어떤 구름이든 좋아" else friendTitle(state.friend), 42f, ink, true)); gap(card, 24)
        card.addView(label(reply.ifBlank { "새롭게 보이는 게 있으면 알려줘." }, 29f, ink)); gap(card, 34)
        micButton = fullButton(card, if (armed) "마이크 끄기" else "이야기하기", true) { toggleMicrophone() }
        gap(card, 14)
        pair(card, button("잠깐 쉴래") { applyTurn(CloudEngine.rest(state)) }, button("도와줘") { applyTurn(CloudEngine.help(state)) })
        gap(card, 22)
        statusView = label(voiceStatus, 21f, muted).also { card.addView(it) }
        if (undo.isNotEmpty()) { gap(card, 22); card.addView(button("방금 말 되돌리기") { undoLast() }, LinearLayout.LayoutParams(-1, dp(72))) }
    }
    private fun resting(card: LinearLayout) {
        card.addView(label("잠깐 쉬어도 좋아", 43f, ink, true)); gap(card, 24)
        card.addView(label("구름이 다시 눈에 들어오면\n그때 이어서 놀아요.", 29f, muted)); gap(card, 40)
        fullButton(card, "다시 만날래", true) { if (foreground && !restricted) applyTurn(CloudEngine.start(state)) }
        gap(card, 22); card.addView(label("지금은 마이크가 꺼져 있어요", 21f, muted))
    }
    private fun friendTitle(friend: CloudFriend?) = friend?.nickname?.takeIf(String::isNotBlank) ?: friend?.label ?: "우리의 구름 친구"
    private fun memoryLine(saved: CloudState): String {
        val first = saved.memories.firstOrNull()?.friend
        val last = saved.friend
        if (first == null || last == null) return "오늘은 하늘과 함께 쉬었어요."
        return if (first.form != last.form || first.label != last.label) "처음엔 ${first.label}, 나중엔 ${last.label}."
        else last.features.take(2).joinToString(" ") { it.label }.let { if (it.isBlank()) "네 눈에 들어온 소중한 친구." else "$it 모습을 기억해요." }
    }
    private fun keepsake(card: LinearLayout, saved: CloudState, wide: Boolean) {
        card.addView(label("오늘의 구름 친구", 22f, blue, true)); gap(card, 16)
        card.addView(label(if (saved.friend == null) "다음에 또 만나" else friendTitle(saved.friend), 43f, ink, true)); gap(card, 24)
        if (!wide) card.addView(CloudFriendView(this, saved.friend, true), LinearLayout.LayoutParams(-1, dp(260)))
        card.addView(label(memoryLine(saved), 28f, ink)); gap(card, 24)
        card.addView(label(if (saved.friend == null) "구름을 만나지 않아도 괜찮아요." else "네가 들려준 모습으로 그렸어.\n이 한 장은 여기에 기억해둘게.", 24f, muted)); gap(card, 32)
        fullButton(card, "새 여행 시작", true) { newTrip() }
        if (saved.friend != null) { gap(card, 14); fullButton(card, "다시 들려줘") { say(memoryLine(saved), false) } }
    }

    private fun say(words: String?, listenAfter: Boolean) {
        if (words.isNullOrBlank() || !foreground || restricted || !carReady) return
        voice.speak(words)
        if (listenAfter && state.phase == CloudPhase.WATCHING) { armed = voice.enableCommands(); updateMicLabel() }
    }
    private fun rememberUndo() { undo.addLast(state); while (undo.size > 10) undo.removeFirst() }
    private fun applyTurn(turn: CloudTurn, continueListening: Boolean = armed) {
        if (!foreground || restricted || !carReady) return
        if (turn.outcome == CloudOutcome.UNDO) { undoLast(continueListening); return }
        if (turn.outcome == CloudOutcome.REPEAT) { say(reply.ifBlank { "마음에 드는 구름이 있으면 뭐처럼 보이는지 알려줘." }, continueListening); return }
        if (turn.outcome == CloudOutcome.OBSERVED && turn.state.friend != state.friend) rememberUndo()
        state = turn.state
        if (!turn.reply.isNullOrBlank()) reply = turn.reply!!
        if (state.phase != CloudPhase.WATCHING) quiet()
        store.save(state)
        Log.i("CloudFriends", "Cloud turn: ${turn.outcome}; phase=${state.phase}; form=${state.friend?.form}")
        render()
        say(turn.reply, continueListening && state.phase == CloudPhase.WATCHING)
    }
    private fun acceptWords(words: String) { if (playable()) applyTurn(CloudEngine.observe(state, words)) }
    private fun undoLast(continueListening: Boolean = armed) {
        if (!playable()) return
        if (undo.isEmpty()) { say("아직 되돌릴 말이 없어.", continueListening); return }
        state = undo.removeLast().copy(phase = CloudPhase.WATCHING)
        reply = "괜찮아. 방금 전 모습으로 돌아왔어."
        store.save(state); render(); say(reply, continueListening)
    }
    private fun toggleMicrophone() {
        if (!playable()) return
        if (armed) { quiet(); voiceStatus = "마이크가 꺼져 있어요"; render(); return }
        if (voiceConsent) { armed = voice.enableCommands(); render(); return }
        quiet()
        showDialog(AlertDialog.Builder(this).setTitle("구름 이야기를 들려줄래요?")
            .setMessage("말로 알려주면 구름 친구의 모습을 기억해요.\n\n음성은 차량 안에서 처리해요. 녹음이나 말한 문장 전체는 저장하지 않고, 친구의 모양과 별명만 기기에 남겨요. 쉬거나 앱을 벗어나면 마이크가 꺼져요.")
            .setNegativeButton("나중에", null)
            .setPositiveButton("마이크 켜기") { _, _ -> if (playable()) { voiceConsent = true; armed = voice.enableCommands(); render() } }.create())
    }
    private fun showDialog(next: AlertDialog) {
        dialog?.dismiss(); dialog = next
        next.setOnDismissListener { if (dialog === next) dialog = null }
        next.show()
    }
    private fun parentMenu() {
        quiet()
        val items = arrayOf("말 대신 입력해 보기", "지난 구름 친구 보기", "음성과 저장 안내", "처음부터 새 여행")
        showDialog(AlertDialog.Builder(this).setTitle("보호자 메뉴").setItems(items) { _, index ->
            when (index) {
                0 -> handler.post { tryWords() }
                1 -> handler.post { previousKeepsake() }
                2 -> handler.post { information() }
                3 -> handler.post { newTrip() }
            }
        }.setNegativeButton("닫기", null).create())
    }
    /** Text and example inputs use exactly the same reducer as the microphone. */
    private fun tryWords() {
        if (!foreground || restricted || !carReady) return
        quiet()
        val panel = column().apply { setPadding(dp(24), dp(16), dp(24), dp(12)) }
        val field = EditText(this).apply {
            hint = "아이가 한 말을 입력해 주세요"; textSize = 23f; maxLines = 3
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            filters = arrayOf(android.text.InputFilter.LengthFilter(160))
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
        }
        panel.addView(field, LinearLayout.LayoutParams(-1, dp(100))); gap(panel, 12)
        panel.addView(label("예시를 누르거나 자유롭게 입력해 보세요.", 19f, muted)); gap(panel, 12)
        var entryDialog: AlertDialog? = null
        fun submit(words: String) {
            if (words.isBlank()) return
            entryDialog?.dismiss()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(field.windowToken, 0)
            if (!foreground || restricted) return
            if (state.phase == CloudPhase.WELCOME || state.phase == CloudPhase.KEEPSAKE) {
                if (state.phase == CloudPhase.KEEPSAKE) { state = CloudEngine.create(); undo.clear() }
                state = CloudEngine.start(state).state
            } else if (state.phase == CloudPhase.RESTING) state = CloudEngine.start(state).state
            acceptWords(words)
        }
        listOf("고래 같아. 꼬리가 엄청 길어!", "이번엔 날개 달린 용 같아", "그대로야", "구름이 안 보여").forEach { example ->
            panel.addView(button(example) { submit(example) }, LinearLayout.LayoutParams(-1, dp(64)).apply { bottomMargin = dp(8) })
        }
        entryDialog = AlertDialog.Builder(this).setTitle("말 대신 입력해 보기").setView(panel)
            .setNegativeButton("닫기", null).setPositiveButton("말 전하기", null).create()
        showDialog(entryDialog!!)
        entryDialog!!.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { submit(field.text.toString()) }
    }
    private fun information() {
        val message = "아이의 말로 함께 상상하는 놀이예요.\n실제 구름을 촬영하거나 판별하지 않아요.\n\n친구의 모양과 별명만 이 기기에 남아요.\n음성 녹음과 전체 발화는 저장하지 않아요.\n\n말이 없으면 조용히 기다리며 듣기를 마쳐요.\n다시 말할 때 ‘이야기하기’를 눌러 주세요.\n\n${voice.engineLabel}\n현재 버전은 정차 상태에서 시연할 수 있어요."
        showDialog(AlertDialog.Builder(this).setTitle("음성과 저장 안내").setMessage(message).setPositiveButton("확인", null).create())
    }
    private fun previousKeepsake() {
        val saved = store.lastKeepsake()
        if (saved?.friend == null) {
            showDialog(AlertDialog.Builder(this).setTitle("아직 여행 그림이 없어요").setMessage("여행을 마치면 구름 친구 한 장이 남아요.").setPositiveButton("확인", null).create()); return
        }
        val panel = column().apply { setPadding(dp(28), dp(12), dp(28), dp(24)) }
        panel.addView(CloudFriendView(this, saved.friend, true), LinearLayout.LayoutParams(-1, dp(280)))
        panel.addView(label(memoryLine(saved), 23f))
        showDialog(AlertDialog.Builder(this).setTitle(friendTitle(saved.friend)).setView(panel).setPositiveButton("닫기", null).create())
    }
    private fun newTrip() {
        if (!foreground || restricted || !carReady) return
        quiet()
        showDialog(AlertDialog.Builder(this).setTitle("새 여행을 시작할까요?")
            .setMessage("마지막 여행 그림은 보호자 메뉴에서 다시 볼 수 있어요.")
            .setNegativeButton("취소", null).setPositiveButton("새 여행") { _, _ ->
                state = CloudEngine.create(); undo.clear(); reply = ""; voiceConsent = false; store.save(state); render()
            }.create())
    }
}
