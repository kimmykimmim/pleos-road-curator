package dev.changbak.explorer

import android.app.Activity
import android.app.Instrumentation
import android.graphics.Bitmap
import android.opengl.EGL14
import android.opengl.GLES20
import android.os.Bundle
import dev.changbak.explorer.domain.TravelEngine
import dev.changbak.explorer.domain.TravelState
import java.io.File
import java.nio.ByteBuffer

/** Renders synthetic art to an offscreen buffer. Does not capture or operate the user's screen. */
class SceneRenderCheck : Instrumentation() {
    private var requestedCheck: String? = null
    override fun onCreate(arguments: Bundle?) {
        super.onCreate(arguments)
        requestedCheck = arguments?.getString("check")
        start()
    }

    override fun onStart() {
        val report = Bundle()
        try {
            if (requestedCheck == "chat") {
                report.putString("result", FriendChatTransportCheck.run(targetContext))
                finish(Activity.RESULT_OK, report)
                return
            }
            val output = File(targetContext.filesDir, "scene-render-check").apply { mkdirs() }
            var sample = TravelEngine.start(TravelEngine.create()).state
            sample = TravelEngine.observe(sample, "구름이 동글동글해").state
            val cloudPixels = render(sample, File(output, "friend-cloud.png"))
            sample = TravelEngine.observe(sample, "나뭇잎이 살랑살랑 움직여").state
            sample = TravelEngine.observe(sample, "강물이 반짝여").state
            val landscapePixels = render(sample, File(output, "friend-landscape.png"))
            sample = TravelEngine.observe(sample, "그거 강이 아니라 바다였어").state
            render(sample, File(output, "friend-sea.png"))
            sample = TravelEngine.observe(sample, "날개 달아줘").state
            render(sample, File(output, "friend-wings.png"))
            val changed = cloudPixels.indices.count { cloudPixels[it] != landscapePixels[it] }
            check(changed > 2500) { "Accumulated scenery did not visibly change the character" }
            val green = landscapePixels.count { c ->
                val r = c shr 16 and 255; val g = c shr 8 and 255; val b = c and 255
                g > r + 12 && g > b + 3
            }
            check(green > 300) { "Leaf ears are missing from the rendered sample" }
            report.putString("result", "PASS: four offscreen 3D renders, scenery changes, and leaf ears")
            report.putString("artifacts", output.absolutePath)
            report.putInt("changed_pixels", changed)
            report.putInt("leaf_pixels", green)
            finish(Activity.RESULT_OK, report)
        } catch (error: Throwable) {
            report.putString("result", "FAIL: ${error.javaClass.simpleName}: ${error.message}")
            finish(Activity.RESULT_CANCELED, report)
        }
    }

    private fun render(state: TravelState, output: File): IntArray {
        val width = 720
        val height = 600
        val display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        check(display != EGL14.EGL_NO_DISPLAY) { "No EGL display" }
        val version = IntArray(2)
        check(EGL14.eglInitialize(display, version, 0, version, 1)) { "EGL initialization failed" }
        val configs = arrayOfNulls<android.opengl.EGLConfig>(1)
        val count = IntArray(1)
        val attributes = intArrayOf(
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8, EGL14.EGL_DEPTH_SIZE, 16, EGL14.EGL_NONE,
        )
        check(EGL14.eglChooseConfig(display, attributes, 0, configs, 0, 1, count, 0) && count[0] > 0) { "No GLES2 pbuffer config" }
        val context = EGL14.eglCreateContext(display, configs[0], EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        check(context != EGL14.EGL_NO_CONTEXT) { "No GLES2 context" }
        val surface = EGL14.eglCreatePbufferSurface(display, configs[0],
            intArrayOf(EGL14.EGL_WIDTH, width, EGL14.EGL_HEIGHT, height, EGL14.EGL_NONE), 0)
        check(surface != EGL14.EGL_NO_SURFACE) { "No pbuffer surface" }
        try {
            check(EGL14.eglMakeCurrent(display, surface, surface, context)) { "Cannot make render context current" }
            var renderError: String? = null
            val renderer = createLandscapeRendererForCheck(state) { renderError = it }
            renderer.onSurfaceCreated(null, null)
            renderer.onSurfaceChanged(null, width, height)
            renderer.onDrawFrame(null)
            GLES20.glFinish()
            check(renderError == null) { renderError.orEmpty() }
            check(GLES20.glGetError() == GLES20.GL_NO_ERROR) { "OpenGL draw failed" }
            val rgba = ByteBuffer.allocateDirect(width * height * 4)
            GLES20.glReadPixels(0, 0, width, height, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, rgba)
            check(GLES20.glGetError() == GLES20.GL_NO_ERROR) { "OpenGL readback failed" }
            val pixels = IntArray(width * height)
            for (y in 0 until height) for (x in 0 until width) {
                val i = (y * width + x) * 4
                val r = rgba.get(i).toInt() and 255
                val g = rgba.get(i + 1).toInt() and 255
                val b = rgba.get(i + 2).toInt() and 255
                pixels[(height - 1 - y) * width + x] = (255 shl 24) or (r shl 16) or (g shl 8) or b
            }
            val background = pixels[0]
            check(pixels.count { it != background } > 4000) { "Rendered image is blank" }
            val bitmap = Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888)
            try { output.outputStream().use { check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)) } }
            finally { bitmap.recycle() }
            return pixels
        } finally {
            EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(display, surface)
            EGL14.eglDestroyContext(display, context)
            EGL14.eglTerminate(display)
        }
    }
}
